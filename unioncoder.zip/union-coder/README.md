# UNIONcoder AI Chat Platform - Employee Assistance MVP

## 🚀 Overview

UNIONcoder is a comprehensive AI-powered employee assistance platform that connects workers with specialized AI legal experts. The platform has been **completely pivoted** from a Union Agent Management tool to an Employee-Facing AI Chat Application.

### 🔄 **CRITICAL PIVOT UPDATE (Version 2.0.0)**

**❌ REMOVED:** 3-Change License Module (License management for union agents)
**✅ ADDED:** AI Agent Chat Module (Employee-facing AI persona interactions)

**OLD:** Mobile app for Union Agents → **NEW:** Mobile app for Employees
**OLD:** Managing license assignments → **NEW:** Chat with AI legal experts
**OLD:** License counter resets → **NEW:** AI persona management and conversation review

## 🏗️ Architecture

### **New Technology Stack**
- **Frontend (Mobile):** React Native (Expo) with NativeWind (Tailwind CSS)
- **Backend (API):** Node.js (TypeScript) with Express
- **Database:** Firebase Firestore (real-time chat storage)
- **Authentication:** Firebase Auth with Role-Based Access Control
- **AI Integration:** Claude/GPT-4 API ready
- **Admin Portal:** Web-based management dashboard

### **New Database Schema**
```javascript
// REMOVED: licenses collection

// NEW COLLECTIONS:
users: {
  userId, email, displayName, currentEmployer, 
  department, jobTitle, joinDate, lastLoginAt, isActive
}

ai_personas: {
  personaId, name, title, specialization, description,
  avatar, systemPrompt, isActive, sortOrder, createdBy
}

conversations: {
  conversationId, userId, personaId, title, status,
  messages[{messageId, sender, content, timestamp}],
  startedAt, lastMessageAt, isResolved, category, tags
}
```

## 🎯 Core Features

### 📱 **Mobile App (React Native)**
1. **Persona Selection Screen** - Choose from specialized AI agents
2. **Main Chat Interface** - Real-time conversations with AI personas
3. **Case History Screen** - View past conversations and status
4. **Profile Management** - User profile and settings

### 🤖 **AI Persona System**
5 default AI legal experts:
- **Sarah Martinez** - Contract Specialist 📋
- **David Chen** - Harassment Expert 🛡️  
- **Maria Rodriguez** - Wage & Benefits Advisor 💰
- **James Thompson** - Termination Rights Specialist ⚖️
- **Lisa Park** - Workplace Safety Advocate 🦺

### ⚙️ **Admin Management Hub**
1. **User Management** - View, activate/deactivate employee accounts
2. **AI Persona Management** - Create, edit, and manage AI agents and prompts
3. **Conversation Review** - Monitor and moderate AI conversations
4. **Analytics Dashboard** - Usage statistics and system health

## 🛡️ Security & RBAC

### **Role-Based Access Control**
- **Employees:** Can chat with AI personas, manage their profile
- **Admins:** Full access to user management, persona management, conversation review

### **API Security**
- JWT token authentication
- Firebase Custom Claims for role verification
- Input validation with Zod schemas
- CORS protection and security headers

## 🚀 Quick Start

### **1. Backend Setup**
```bash
cd union-coder/backend
npm install
cp .env.example .env
# Configure Firebase credentials in .env
npm run dev
```

### **2. Mobile App Setup**
```bash
cd union-coder/frontend
npm install
# Configure Firebase in App.js or app.json
npx expo start
```

### **3. Admin Hub Setup**
```bash
cd union-coder/admin-hub
npm install
npm start
# Access at http://localhost:8081/admin
# Default login: admin@ai-coder.uk / admin123
```

### **4. Firebase Setup**
1. Create Firebase project at https://console.firebase.google.com
2. Enable Authentication (Email/Password)
3. Create Firestore database
4. Generate service account key
5. Configure environment variables

## 🔧 Environment Configuration

### **Backend (.env)**
```env
FIREBASE_PROJECT_ID=your-project-id
FIREBASE_PRIVATE_KEY="-----BEGIN PRIVATE KEY-----..."
FIREBASE_CLIENT_EMAIL=service-account@project.iam.gserviceaccount.com

EXTERNAL_AI_API_KEY=your-anthropic-or-openai-key
EXTERNAL_AI_BASE_URL=https://api.anthropic.com

PORT=3000
NODE_ENV=development
JWT_SECRET=your-jwt-secret
ADMIN_EMAIL=admin@ai-coder.uk
```

### **Mobile (app.json)**
```json
{
  "expo": {
    "name": "UNIONcoder",
    "slug": "union-coder",
    "extra": {
      "firebase": {
        "apiKey": "...",
        "authDomain": "...",
        "projectId": "...",
        "storageBucket": "...",
        "messagingSenderId": "...",
        "appId": "..."
      }
    }
  }
}
```

## 📡 API Endpoints

### **Authentication**
- `POST /users/login` - Track user login
- `GET /users/profile` - Get user profile
- `POST /users/profile` - Create user profile
- `PUT /users/profile` - Update user profile

### **Chat System**
- `GET /personas/active` - Get available AI personas
- `POST /chat/conversations` - Create new conversation
- `POST /chat/messages` - Send message to AI
- `GET /chat/conversations` - Get user conversations
- `DELETE /chat/conversations/:id` - Delete conversation

### **Admin (RBAC Protected)**
- `GET /admin/users` - User management
- `GET /admin/personas` - AI persona management
- `GET /admin/conversations` - Conversation review
- `GET /admin/dashboard` - Admin analytics

## 🧪 Testing

### **Backend Tests**
```bash
cd backend
npm test
```

### **Mobile Tests**
```bash
cd frontend
npm test
```

### **Key Test Coverage**
- ✅ AI chat conversation creation and messaging
- ✅ AI persona system prompts and responses
- ✅ User authentication and profile management
- ✅ Admin RBAC and permission validation
- ✅ Firestore transaction integrity

## 🎨 Design System

### **Brand Colors (Strict)**
- **Primary/Background:** `#FFFFFF` (White)
- **Neutral/Text:** `#4A5568` (Gray)
- **Accent 1 (CTA):** `#FF8C00` (Orange)
- **Accent 2 (Warning):** `#FFD700` (Yellow)
- **Brand/Header:** `#8A2BE2` (Purple)

### **UI Components**
- All buttons use Accent Orange (`#FF8C00`)
- Headers/navigation use Brand Purple (`#8A2BE2`)
- Status indicators use Warning Yellow (`#FFD700`)
- Text and borders use Neutral Gray (`#4A5568`)

## 📊 Analytics & Monitoring

### **System Health Monitoring**
- API response times
- AI service availability
- Database connection status
- Active user tracking

### **Conversation Analytics**
- Popular AI personas
- Common conversation categories
- User engagement metrics
- Resolution rates

## 🔍 Troubleshooting

### **Common Issues**
1. **Firebase Connection:** Verify service account credentials
2. **AI Service:** Check API keys and rate limits
3. **Authentication:** Ensure Firebase Auth rules are properly configured
4. **CORS:** Verify frontend URLs in CORS configuration

### **Debug Mode**
```bash
# Backend with debug logging
DEBUG=* npm run dev

# Mobile with debug logs
EXPO_DEBUG=1 npx expo start
```

## 🚀 Deployment

### **Backend (Production)**
```bash
npm run build
npm start
```

### **Mobile (Production)**
```bash
npx expo build:android
npx expo build:ios
```

### **Admin Hub (Production)**
```bash
NODE_ENV=production npm start
```

## 📞 Support & Contact

- **Technical Support:** admin@ai-coder.uk
- **Website:** www.ai-coder.uk
- **Documentation:** GitHub Repository Wiki

## 📄 License

© 2024 UNIONcoder. All rights reserved.
Technical contact: admin@ai-coder.uk | Legal information: www.ai-coder.uk

---

## 🔄 Version History

### **v2.0.0 (Current) - Pivoted Architecture**
- ❌ Removed: 3-Change License Module
- ✅ Added: AI Chat Module
- ✅ Added: Employee user management
- ✅ Added: AI persona management
- ✅ Added: Conversation review system
- ✅ Updated: Mobile app for employee use

### **v1.0.0 - Original**
- ✅ License management system
- ✅ Union agent tools
- ✅ Basic admin functionality

---

**🎯 UNIONcoder is now focused on helping EMPLOYEES get AI-powered workplace legal assistance!**