const express = require('express');
const cors = require('cors');
const axios = require('axios');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 8081;

// Backend API URL
const API_BASE_URL = process.env.API_BASE_URL || 'http://localhost:3000/api';

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Admin authentication middleware (simplified for demo)
const adminAuth = (req, res, next) => {
  const authHeader = req.headers.authorization;
  
  // In production, implement proper JWT validation
  // For demo, we'll use a simple admin token
  if (authHeader === 'Bearer admin-token-123') {
    next();
  } else {
    res.status(401).json({ error: 'Unauthorized: Admin access required' });
  }
};

// API Routes - Proxy to backend
app.all('/api/*', adminAuth, async (req, res) => {
  try {
    const targetUrl = `${API_BASE_URL}${req.path.replace('/api', '')}`;
    
    const response = await axios({
      method: req.method,
      url: targetUrl,
      data: req.body,
      headers: {
        'Authorization': req.headers.authorization,
        'Content-Type': 'application/json',
      },
    });

    res.status(response.status).json(response.data);
  } catch (error) {
    console.error('Proxy error:', error.message);
    
    if (error.response) {
      res.status(error.response.status).json(error.response.data);
    } else {
      res.status(500).json({ 
        error: 'Internal server error',
        message: 'Failed to connect to backend API'
      });
    }
  }
});

// Serve admin dashboard
app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Admin login endpoint (simplified)
app.post('/admin/login', async (req, res) => {
  const { email, password } = req.body;
  
  // Simple admin check (in production, use proper authentication)
  if (email === 'admin@ai-coder.uk' && password === 'admin123') {
    res.json({
      success: true,
      token: 'admin-token-123',
      user: {
        email: 'admin@ai-coder.uk',
        role: 'admin',
        displayName: 'System Administrator',
      },
    });
  } else {
    res.status(401).json({
      success: false,
      error: 'Invalid credentials',
    });
  }
});

// Health check
app.get('/health', (req, res) => {
  res.json({
    status: 'healthy',
    service: 'UNIONcoder Admin Hub',
    timestamp: new Date(),
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`
🏢 UNIONcoder Admin Hub Started Successfully!

📊 Server Information:
   • Port: ${PORT}
   • Environment: ${process.env.NODE_ENV || 'development'}
   • API Proxy: ${API_BASE_URL}

🔗 Available URLs:
   • Admin Dashboard: http://localhost:${PORT}/admin
   • API Proxy: http://localhost:${PORT}/api/admin/*
   • Health Check: http://localhost:${PORT}/health

👤 Default Admin Login:
   • Email: admin@ai-coder.uk
   • Password: admin123

📧 Contact: admin@ai-coder.uk
🌐 Website: www.ai-coder.uk

Admin Hub ready for management tasks! 🎯
`);
});

module.exports = app;