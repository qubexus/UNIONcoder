// UNIONcoder Admin Hub JavaScript

class AdminHub {
    constructor() {
        this.authToken = localStorage.getItem('adminToken');
        this.currentUser = null;
        this.apiBase = '/api';
        
        this.init();
    }

    init() {
        if (this.authToken) {
            this.showDashboard();
        } else {
            this.showLogin();
        }
        
        this.bindEvents();
    }

    bindEvents() {
        // Login form
        document.getElementById('loginForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleLogin();
        });

        // Logout
        document.getElementById('logoutBtn').addEventListener('click', () => {
            this.handleLogout();
        });

        // Sidebar navigation
        document.querySelectorAll('.sidebar-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const section = link.dataset.section;
                this.showSection(section);
                
                // Update active state
                document.querySelectorAll('.sidebar-link').forEach(l => l.classList.remove('active'));
                link.classList.add('active');
            });
        });
    }

    async handleLogin() {
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;

        try {
            const response = await fetch('/admin/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ email, password }),
            });

            const data = await response.json();

            if (data.success) {
                this.authToken = data.token;
                this.currentUser = data.user;
                localStorage.setItem('adminToken', this.authToken);
                this.showDashboard();
            } else {
                this.showError('Invalid credentials');
            }
        } catch (error) {
            this.showError('Login failed. Please try again.');
        }
    }

    handleLogout() {
        this.authToken = null;
        this.currentUser = null;
        localStorage.removeItem('adminToken');
        this.showLogin();
    }

    showLogin() {
        document.getElementById('loginScreen').classList.remove('hidden');
        document.getElementById('dashboardScreen').classList.add('hidden');
    }

    showDashboard() {
        document.getElementById('loginScreen').classList.add('hidden');
        document.getElementById('dashboardScreen').classList.remove('hidden');
        this.loadDashboardData();
    }

    showSection(section) {
        // Hide all sections
        document.querySelectorAll('.content-section').forEach(s => {
            s.classList.add('hidden');
        });

        // Show selected section
        document.getElementById(`${section}Section`).classList.remove('hidden');
        
        // Update page title
        const titles = {
            dashboard: 'Dashboard',
            users: 'User Management',
            personas: 'AI Persona Management',
            conversations: 'Conversation Review',
            analytics: 'Analytics'
        };
        document.getElementById('pageTitle').textContent = titles[section] || 'Dashboard';

        // Load section data
        switch (section) {
            case 'dashboard':
                this.loadDashboardData();
                break;
            case 'users':
                this.loadUsers();
                break;
            case 'personas':
                this.loadPersonas();
                break;
            case 'conversations':
                this.loadConversations();
                break;
            case 'analytics':
                this.loadAnalytics();
                break;
        }
    }

    async apiCall(endpoint, options = {}) {
        const defaultOptions = {
            headers: {
                'Authorization': `Bearer ${this.authToken}`,
                'Content-Type': 'application/json',
            },
        };

        const response = await fetch(`${this.apiBase}${endpoint}`, {
            ...defaultOptions,
            ...options,
        });

        if (!response.ok) {
            throw new Error(`API Error: ${response.status}`);
        }

        return await response.json();
    }

    async loadDashboardData() {
        try {
            this.showLoading(true);
            
            // Load dashboard statistics
            const dashboardData = await this.apiCall('/admin/dashboard');
            
            if (dashboardData.success) {
                const { users, personas, conversations } = dashboardData.data;
                
                // Update stats
                document.getElementById('totalUsers').textContent = users.totalUsers || 0;
                document.getElementById('activeConversations').textContent = conversations.activeConversations || 0;
                document.getElementById('totalPersonas').textContent = personas.totalPersonas || 0;
                
                // Load recent conversations
                await this.loadRecentConversations();
                
                // Load popular personas
                await this.loadPopularPersonas();
            }
        } catch (error) {
            console.error('Failed to load dashboard data:', error);
            this.showError('Failed to load dashboard data');
        } finally {
            this.showLoading(false);
        }
    }

    async loadRecentConversations() {
        try {
            const data = await this.apiCall('/admin/conversations?limit=5');
            
            if (data.success) {
                const container = document.getElementById('recentConversations');
                
                if (data.data.length === 0) {
                    container.innerHTML = '<p class="text-gray-500">No recent conversations</p>';
                    return;
                }

                container.innerHTML = data.data.map(conv => `
                    <div class="p-3 border rounded-lg hover:bg-gray-50">
                        <div class="flex justify-between items-start">
                            <div>
                                <p class="font-semibold text-sm">${conv.title || 'Untitled Conversation'}</p>
                                <p class="text-xs text-gray-500">User: ${conv.userId}</p>
                                <p class="text-xs text-gray-500">Messages: ${conv.messages?.length || 0}</p>
                            </div>
                            <span class="text-xs px-2 py-1 bg-blue-100 text-blue-800 rounded">
                                ${conv.status || 'active'}
                            </span>
                        </div>
                    </div>
                `).join('');
            }
        } catch (error) {
            console.error('Failed to load recent conversations:', error);
        }
    }

    async loadPopularPersonas() {
        try {
            const data = await this.apiCall('/admin/personas/stats');
            
            if (data.success) {
                const container = document.getElementById('popularPersonas');
                
                if (data.data.personasBySpecialization.length === 0) {
                    container.innerHTML = '<p class="text-gray-500">No personas available</p>';
                    return;
                }

                container.innerHTML = data.data.personasBySpecialization.map(persona => `
                    <div class="flex justify-between items-center p-3 border rounded-lg">
                        <div>
                            <p class="font-semibold text-sm">${persona.specialization}</p>
                            <p class="text-xs text-gray-500">${persona.count} conversations</p>
                        </div>
                        <div class="text-purple-600">
                            <i class="fas fa-robot"></i>
                        </div>
                    </div>
                `).join('');
            }
        } catch (error) {
            console.error('Failed to load popular personas:', error);
        }
    }

    async loadUsers() {
        try {
            this.showLoading(true);
            
            const data = await this.apiCall('/admin/users');
            
            if (data.success) {
                const tbody = document.getElementById('usersTableBody');
                
                if (data.data.length === 0) {
                    tbody.innerHTML = '<tr><td colspan="5" class="px-6 py-4 text-center text-gray-500">No users found</td></tr>';
                    return;
                }

                tbody.innerHTML = data.data.map(user => `
                    <tr class="table-row-hover">
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div>
                                <div class="text-sm font-medium text-gray-900">${user.displayName || 'Unknown'}</div>
                                <div class="text-sm text-gray-500">${user.email}</div>
                            </div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            ${user.currentEmployer || 'Not specified'}
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                                user.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                            }">
                                ${user.isActive ? 'Active' : 'Inactive'}
                            </span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            ${new Date(user.createdAt).toLocaleDateString()}
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            <button class="text-purple-600 hover:text-purple-900 mr-3" onclick="adminHub.editUser('${user.userId}')">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="text-red-600 hover:text-red-900" onclick="adminHub.toggleUserStatus('${user.userId}', ${!user.isActive})">
                                <i class="fas fa-${user.isActive ? 'ban' : 'check'}"></i>
                            </button>
                        </td>
                    </tr>
                `).join('');
            }
        } catch (error) {
            console.error('Failed to load users:', error);
            this.showError('Failed to load users');
        } finally {
            this.showLoading(false);
        }
    }

    async loadPersonas() {
        try {
            this.showLoading(true);
            
            const data = await this.apiCall('/admin/personas');
            
            if (data.success) {
                const container = document.getElementById('personasGrid');
                
                if (data.data.length === 0) {
                    container.innerHTML = '<div class="col-span-full text-center text-gray-500 py-8">No AI personas found</div>';
                    return;
                }

                container.innerHTML = data.data.map(persona => `
                    <div class="border rounded-lg p-6 hover:shadow-lg transition-shadow">
                        <div class="flex items-center justify-between mb-4">
                            <div class="text-3xl">${persona.avatar}</div>
                            <span class="px-2 py-1 text-xs rounded-full ${
                                persona.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                            }">
                                ${persona.isActive ? 'Active' : 'Inactive'}
                            </span>
                        </div>
                        <h3 class="text-lg font-semibold mb-2">${persona.name}</h3>
                        <p class="text-sm text-gray-600 mb-2">${persona.title}</p>
                        <p class="text-sm text-gray-500 mb-4">${persona.specialization}</p>
                        <p class="text-xs text-gray-400 mb-4 line-clamp-3">${persona.description}</p>
                        <div class="flex space-x-2">
                            <button class="flex-1 btn-primary text-sm" onclick="adminHub.editPersona('${persona.personaId}')">
                                <i class="fas fa-edit mr-1"></i> Edit
                            </button>
                            <button class="flex-1 btn-accent text-sm" onclick="adminHub.togglePersonaStatus('${persona.personaId}', ${!persona.isActive})">
                                <i class="fas fa-${persona.isActive ? 'pause' : 'play'} mr-1"></i> ${persona.isActive ? 'Deactivate' : 'Activate'}
                            </button>
                        </div>
                    </div>
                `).join('');
            }
        } catch (error) {
            console.error('Failed to load personas:', error);
            this.showError('Failed to load personas');
        } finally {
            this.showLoading(false);
        }
    }

    async loadConversations() {
        try {
            this.showLoading(true);
            
            const data = await this.apiCall('/admin/conversations');
            
            if (data.success) {
                const container = document.getElementById('conversationsList');
                
                if (data.data.length === 0) {
                    container.innerHTML = '<div class="px-6 py-4 text-center text-gray-500">No conversations found</div>';
                    return;
                }

                container.innerHTML = data.data.map(conv => `
                    <div class="px-6 py-4 hover:bg-gray-50">
                        <div class="flex justify-between items-start">
                            <div class="flex-1">
                                <div class="flex items-center space-x-2 mb-2">
                                    <h3 class="text-sm font-semibold">${conv.title || 'Untitled Conversation'}</h3>
                                    <span class="px-2 py-1 text-xs rounded-full ${
                                        conv.status === 'active' ? 'bg-green-100 text-green-800' : 
                                        conv.status === 'flagged' ? 'bg-red-100 text-red-800' : 
                                        'bg-gray-100 text-gray-800'
                                    }">
                                        ${conv.status || 'active'}
                                    </span>
                                    ${conv.category ? `<span class="px-2 py-1 text-xs bg-yellow-100 text-yellow-800 rounded-full">${conv.category}</span>` : ''}
                                </div>
                                <p class="text-sm text-gray-600 mb-2">User: ${conv.userId}</p>
                                <p class="text-sm text-gray-500">
                                    ${conv.messages?.length || 0} messages • 
                                    Started: ${new Date(conv.startedAt).toLocaleDateString()} • 
                                    Last: ${new Date(conv.lastMessageAt).toLocaleDateString()}
                                </p>
                                ${conv.tags && conv.tags.length > 0 ? `
                                    <div class="flex flex-wrap gap-1 mt-2">
                                        ${conv.tags.slice(0, 3).map(tag => `
                                            <span class="text-xs px-2 py-1 bg-gray-100 text-gray-600 rounded">${tag}</span>
                                        `).join('')}
                                    </div>
                                ` : ''}
                            </div>
                            <div class="flex space-x-2 ml-4">
                                <button class="text-purple-600 hover:text-purple-900" onclick="adminHub.viewConversation('${conv.conversationId}')">
                                    <i class="fas fa-eye"></i>
                                </button>
                                <button class="text-red-600 hover:text-red-900" onclick="adminHub.flagConversation('${conv.conversationId}')">
                                    <i class="fas fa-flag"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                `).join('');
            }
        } catch (error) {
            console.error('Failed to load conversations:', error);
            this.showError('Failed to load conversations');
        } finally {
            this.showLoading(false);
        }
    }

    async loadAnalytics() {
        try {
            this.showLoading(true);
            
            // Load user stats
            const userStats = await this.apiCall('/admin/users/stats');
            if (userStats.success) {
                const { totalUsers, newUsersThisMonth } = userStats.data;
                document.getElementById('dailyActiveUsers').textContent = totalUsers || 0;
                document.getElementById('newUsersMonth').textContent = newUsersThisMonth || 0;
            }

            // Placeholder for other analytics
            document.getElementById('totalMessages').textContent = '1,234';
            document.getElementById('avgResponseTime').textContent = '850ms';
            
        } catch (error) {
            console.error('Failed to load analytics:', error);
            this.showError('Failed to load analytics');
        } finally {
            this.showLoading(false);
        }
    }

    async toggleUserStatus(userId, newStatus) {
        try {
            const action = newStatus ? 'activate' : 'deactivate';
            const data = await this.apiCall(`/admin/users/${userId}/${action}`, {
                method: 'POST',
            });
            
            if (data.success) {
                this.showSuccess(`User ${action}d successfully`);
                this.loadUsers();
            }
        } catch (error) {
            this.showError(`Failed to ${action} user`);
        }
    }

    async togglePersonaStatus(personaId, newStatus) {
        try {
            const action = newStatus ? 'activate' : 'deactivate';
            const data = await this.apiCall(`/personas/${personaId}/${action}`, {
                method: 'POST',
            });
            
            if (data.success) {
                this.showSuccess(`Persona ${action}d successfully`);
                this.loadPersonas();
            }
        } catch (error) {
            this.showError(`Failed to ${action} persona`);
        }
    }

    showLoading(show) {
        const overlay = document.getElementById('loadingOverlay');
        if (show) {
            overlay.classList.remove('hidden');
        } else {
            overlay.classList.add('hidden');
        }
    }

    showError(message) {
        // Simple alert for now - could be enhanced with a toast component
        alert('Error: ' + message);
    }

    showSuccess(message) {
        // Simple alert for now - could be enhanced with a toast component
        alert('Success: ' + message);
    }

    // Placeholder methods for future functionality
    editUser(userId) {
        this.showSuccess('Edit user functionality coming soon');
    }

    editPersona(personaId) {
        this.showSuccess('Edit persona functionality coming soon');
    }

    viewConversation(conversationId) {
        this.showSuccess('View conversation functionality coming soon');
    }

    flagConversation(conversationId) {
        this.showSuccess('Flag conversation functionality coming soon');
    }

    showCreateUserModal() {
        this.showSuccess('Create user functionality coming soon');
    }

    showCreatePersonaModal() {
        this.showSuccess('Create persona functionality coming soon');
    }
}

// Initialize the admin hub
const adminHub = new AdminHub();