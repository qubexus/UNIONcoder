import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import dotenv from 'dotenv';

// Import NEW routes (removed license-focused routes)
import chatRoutes from './routes/chat';
import userRoutes from './routes/users';
import personaRoutes from './routes/personas';
import aiRoutes from './routes/ai';
import adminRoutes from './routes/admin';

// Import services for initialization
import { AIPersonaService } from './services/aiPersonaService';

// Load environment variables
dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// Security middleware
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:", "https:"],
    },
  },
}));

// CORS configuration
app.use(cors({
  origin: process.env.NODE_ENV === 'production' 
    ? ['https://your-frontend-domain.com', 'https://your-admin-domain.com']
    : ['http://localhost:19006', 'http://localhost:3000', 'http://localhost:8081'], // Expo default ports
  credentials: true,
}));

// Body parsing middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Request logging middleware
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.path} - IP: ${req.ip}`);
  next();
});

// Health check endpoint
app.get('/health', (req, res) => {
  res.status(200).json({
    success: true,
    message: 'UNIONcoder AI Chat API is running',
    timestamp: new Date(),
    version: '2.0.0', // Updated version for pivoted architecture
    environment: process.env.NODE_ENV || 'development',
    features: {
      aiChat: true,
      personaManagement: true,
      userManagement: true,
      adminHub: true,
    },
  });
});

// NEW API Routes - Chat-focused architecture
app.use('/api/chat', chatRoutes);
app.use('/api/users', userRoutes);
app.use('/api/personas', personaRoutes);
app.use('/api/ai', aiRoutes);
app.use('/api/admin', adminRoutes);

// Root endpoint
app.get('/', (req, res) => {
  res.status(200).json({
    success: true,
    message: 'Welcome to UNIONcoder AI Chat API',
    version: '2.0.0',
    description: 'Employee assistance platform powered by AI personas',
    endpoints: {
      health: '/health',
      chat: '/api/chat',
      users: '/api/users',
      personas: '/api/personas',
      ai: '/api/ai',
      admin: '/api/admin',
    },
    documentation: 'https://github.com/unioncoder/api-docs',
    contact: 'admin@ai-coder.uk',
    website: 'www.ai-coder.uk',
  });
});

// 404 handler
app.use('*', (req, res) => {
  res.status(404).json({
    success: false,
    error: 'Endpoint not found',
    message: `Cannot ${req.method} ${req.originalUrl}`,
    availableEndpoints: {
      chat: [
        'POST /api/chat/conversations - Create new conversation',
        'POST /api/chat/messages - Send message',
        'GET /api/chat/conversations - Get user conversations',
        'GET /api/chat/conversations/:id - Get specific conversation',
        'DELETE /api/chat/conversations/:id - Delete conversation',
      ],
      users: [
        'GET /api/users/profile - Get user profile',
        'POST /api/users/profile - Create user profile',
        'PUT /api/users/profile - Update user profile',
        'POST /api/users/login - Track login',
        'GET /api/users/stats - Get user statistics',
      ],
      personas: [
        'GET /api/personas/active - Get active personas',
        'GET /api/personas/:id - Get specific persona',
        'POST /api/personas - Create persona (admin)',
        'GET /api/personas - Get all personas (admin)',
        'PUT /api/personas/:id - Update persona (admin)',
        'POST /api/personas/:id/deactivate - Deactivate persona (admin)',
        'POST /api/personas/:id/activate - Activate persona (admin)',
        'DELETE /api/personas/:id - Delete persona (admin)',
        'POST /api/personas/reorder - Reorder personas (admin)',
        'POST /api/personas/initialize-default - Initialize defaults (admin)',
      ],
      ai: [
        'POST /api/ai/case-summary - Generate AI summary',
        'POST /api/ai/sentiment-analysis - Analyze sentiment',
        'GET /api/ai/status - Get AI service status',
      ],
      admin: [
        'GET /api/admin/users - User management',
        'GET /api/admin/conversations - Conversation review',
        'GET /api/admin/personas - Persona management',
        'GET /api/admin/dashboard - Admin dashboard',
        'GET /api/admin/health - System health',
      ],
    },
  });
});

// Global error handler
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  console.error('Unhandled error:', err);
  
  res.status(err.status || 500).json({
    success: false,
    error: 'Internal server error',
    message: process.env.NODE_ENV === 'development' ? err.message : 'Something went wrong',
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack }),
  });
});

// Initialize default personas on startup
async function initializeApp() {
  try {
    const aiPersonaService = new AIPersonaService();
    await aiPersonaService.initializeDefaultPersonas();
    console.log('✅ Default AI personas initialized successfully');
  } catch (error) {
    console.error('❌ Failed to initialize default personas:', error);
  }
}

// Start server
app.listen(PORT, async () => {
  console.log(`
🚀 UNIONcoder AI Chat API Server Started Successfully!

📊 Server Information:
   • Port: ${PORT}
   • Environment: ${process.env.NODE_ENV || 'development'}
   • Version: 2.0.0 (Pivoted Architecture)
   • PID: ${process.pid}

🤖 AI Features Enabled:
   • Real-time chat with AI personas
   • Multiple specialized AI agents
   • Conversation management
   • User profile management
   • Admin dashboard

🔗 Available Endpoints:
   • Health Check: http://localhost:${PORT}/health
   • API Root: http://localhost:${PORT}/
   • Chat API: http://localhost:${PORT}/api/chat
   • Users API: http://localhost:${PORT}/api/users
   • Personas API: http://localhost:${PORT}/api/personas
   • AI Services: http://localhost:${PORT}/api/ai
   • Admin Hub: http://localhost:${PORT}/api/admin

📱 Mobile App Ready: React Native + Expo
⚙️ Admin Portal: Web-based management
🔥 Database: Firebase Firestore
🤖 AI Integration: Claude/GPT-4 ready

📧 Contact: admin@ai-coder.uk
🌐 Website: www.ai-coder.uk

Server is ready to handle AI chat requests! 🎯

Initializing default AI personas...
`);

  // Initialize default personas
  await initializeApp();
  
  console.log(`
🎭 Default AI Personas Ready:
   • Sarah Martinez - Contract Specialist 📋
   • David Chen - Harassment Expert 🛡️
   • Maria Rodriguez - Wage & Benefits Advisor 💰
   • James Thompson - Termination Rights Specialist ⚖️
   • Lisa Park - Workplace Safety Advocate 🦺

All systems operational! 🟢
`);
});

export default app;