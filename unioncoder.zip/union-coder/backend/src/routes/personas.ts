import { Router } from 'express';
import { AIPersonaService } from '../services/aiPersonaService';
import { authenticateUser, AuthenticatedRequest } from '../middleware/rbac';
import { AIPersonaCreateSchema, AIPersonaUpdateSchema } from '../validation/schemas';

const router = Router();
const aiPersonaService = new AIPersonaService();

// Get all active personas (public endpoint - no auth required for persona selection)
router.get('/active', async (req, res) => {
  try {
    const personas = await aiPersonaService.getAllActivePersonas();

    return res.status(200).json({
      success: true,
      data: personas,
      count: personas.length,
    });
  } catch (error) {
    console.error('Get active personas error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error fetching active personas',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// Get a specific persona by ID (public endpoint)
router.get('/:personaId', async (req, res) => {
  try {
    const { personaId } = req.params;
    
    const persona = await aiPersonaService.getPersonaById(personaId);
    
    if (!persona) {
      return res.status(404).json({
        success: false,
        error: 'Persona not found',
      });
    }

    // Only return active personas to public users
    if (!persona.isActive) {
      return res.status(404).json({
        success: false,
        error: 'Persona not available',
      });
    }

    return res.status(200).json({
      success: true,
      data: persona,
    });
  } catch (error) {
    console.error('Get persona error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error fetching persona',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// All following routes require authentication and admin role
router.use(authenticateUser);

// Create a new persona (admin only)
router.post('/', async (req: AuthenticatedRequest, res) => {
  try {
    if (req.user?.role !== 'admin') {
      return res.status(403).json({
        success: false,
        error: 'Forbidden: Admin access required',
      });
    }

    if (!req.user?.uid) {
      return res.status(401).json({
        error: 'User authentication required',
      });
    }

    // Validate input
    const validationResult = AIPersonaCreateSchema.safeParse(req.body);
    
    if (!validationResult.success) {
      return res.status(400).json({
        error: 'Validation failed',
        details: validationResult.error.errors,
      });
    }

    const newPersona = await aiPersonaService.createPersona(validationResult.data, req.user.uid);

    return res.status(201).json({
      success: true,
      message: 'Persona created successfully',
      data: newPersona,
    });
  } catch (error) {
    console.error('Create persona error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error creating persona',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// Get all personas (admin only)
router.get('/', async (req: AuthenticatedRequest, res) => {
  try {
    if (req.user?.role !== 'admin') {
      return res.status(403).json({
        success: false,
        error: 'Forbidden: Admin access required',
      });
    }

    const personas = await aiPersonaService.getAllPersonas();

    return res.status(200).json({
      success: true,
      data: personas,
      count: personas.length,
    });
  } catch (error) {
    console.error('Get all personas error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error fetching personas',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// Update a persona (admin only)
router.put('/:personaId', async (req: AuthenticatedRequest, res) => {
  try {
    if (req.user?.role !== 'admin') {
      return res.status(403).json({
        success: false,
        error: 'Forbidden: Admin access required',
      });
    }

    const { personaId } = req.params;
    
    // Validate input
    const validationResult = AIPersonaUpdateSchema.safeParse(req.body);
    
    if (!validationResult.success) {
      return res.status(400).json({
        error: 'Validation failed',
        details: validationResult.error.errors,
      });
    }

    const updatedPersona = await aiPersonaService.updatePersona(personaId, validationResult.data);

    return res.status(200).json({
      success: true,
      message: 'Persona updated successfully',
      data: updatedPersona,
    });
  } catch (error) {
    console.error('Update persona error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error updating persona',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// Deactivate a persona (admin only)
router.post('/:personaId/deactivate', async (req: AuthenticatedRequest, res) => {
  try {
    if (req.user?.role !== 'admin') {
      return res.status(403).json({
        success: false,
        error: 'Forbidden: Admin access required',
      });
    }

    const { personaId } = req.params;
    
    const result = await aiPersonaService.deactivatePersona(personaId);

    return res.status(result.success ? 200 : 404).json({
      success: result.success,
      message: result.message,
      actionedBy: req.user?.email,
      timestamp: new Date(),
    });
  } catch (error) {
    console.error('Deactivate persona error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error deactivating persona',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// Activate a persona (admin only)
router.post('/:personaId/activate', async (req: AuthenticatedRequest, res) => {
  try {
    if (req.user?.role !== 'admin') {
      return res.status(403).json({
        success: false,
        error: 'Forbidden: Admin access required',
      });
    }

    const { personaId } = req.params;
    
    const result = await aiPersonaService.activatePersona(personaId);

    return res.status(result.success ? 200 : 404).json({
      success: result.success,
      message: result.message,
      actionedBy: req.user?.email,
      timestamp: new Date(),
    });
  } catch (error) {
    console.error('Activate persona error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error activating persona',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// Delete a persona (admin only)
router.delete('/:personaId', async (req: AuthenticatedRequest, res) => {
  try {
    if (req.user?.role !== 'admin') {
      return res.status(403).json({
        success: false,
        error: 'Forbidden: Admin access required',
      });
    }

    const { personaId } = req.params;
    
    const result = await aiPersonaService.deletePersona(personaId);

    return res.status(result.success ? 200 : 404).json({
      success: result.success,
      message: result.message,
      actionedBy: req.user?.email,
      timestamp: new Date(),
    });
  } catch (error) {
    console.error('Delete persona error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error deleting persona',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// Reorder personas (admin only)
router.post('/reorder', async (req: AuthenticatedRequest, res) => {
  try {
    if (req.user?.role !== 'admin') {
      return res.status(403).json({
        success: false,
        error: 'Forbidden: Admin access required',
      });
    }

    const { personaIds } = req.body;

    if (!Array.isArray(personaIds) || personaIds.length === 0) {
      return res.status(400).json({
        success: false,
        error: 'Persona IDs array is required',
      });
    }

    const result = await aiPersonaService.reorderPersonas(personaIds);

    return res.status(result.success ? 200 : 400).json({
      success: result.success,
      message: result.message,
      actionedBy: req.user?.email,
      timestamp: new Date(),
    });
  } catch (error) {
    console.error('Reorder personas error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error reordering personas',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// Initialize default personas (admin only)
router.post('/initialize-default', async (req: AuthenticatedRequest, res) => {
  try {
    if (req.user?.role !== 'admin') {
      return res.status(403).json({
        success: false,
        error: 'Forbidden: Admin access required',
      });
    }

    await aiPersonaService.initializeDefaultPersonas();

    return res.status(200).json({
      success: true,
      message: 'Default personas initialized successfully',
      actionedBy: req.user?.email,
      timestamp: new Date(),
    });
  } catch (error) {
    console.error('Initialize default personas error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error initializing default personas',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

export default router;