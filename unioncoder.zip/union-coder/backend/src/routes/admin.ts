import { Router } from 'express';
import { UserService } from '../services/userService';
import { ChatService } from '../services/chatService';
import { AIPersonaService } from '../services/aiPersonaService';
import { authenticateUser, requireAdmin, AuthenticatedRequest } from '../middleware/rbac';

const router = Router();
const userService = new UserService();
const chatService = new ChatService();
const aiPersonaService = new AIPersonaService();

// All admin routes require admin role
router.use(authenticateUser, requireAdmin);

// UPDATED: User Management (replacing license management)
router.get('/users', async (req: AuthenticatedRequest, res) => {
  try {
    const limit = parseInt(req.query.limit as string) || 50;
    const users = await userService.getAllUsers(limit);

    return res.status(200).json({
      success: true,
      data: users,
      count: users.length,
      requestedBy: req.user?.email,
    });
  } catch (error) {
    console.error('Admin get users error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error fetching users',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// User statistics
router.get('/users/stats', async (req: AuthenticatedRequest, res) => {
  try {
    const stats = await userService.getUserStatistics();

    return res.status(200).json({
      success: true,
      data: stats,
      requestedBy: req.user?.email,
    });
  } catch (error) {
    console.error('Admin get user stats error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error fetching user statistics',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// Deactivate user
router.post('/users/:userId/deactivate', async (req: AuthenticatedRequest, res) => {
  try {
    const { userId } = req.params;
    
    const result = await userService.deactivateUser(userId);
    
    return res.status(result.success ? 200 : 404).json({
      success: result.success,
      message: result.message,
      actionedBy: req.user?.email,
      timestamp: new Date(),
    });
  } catch (error) {
    console.error('Admin deactivate user error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error deactivating user',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// Activate user
router.post('/users/:userId/activate', async (req: AuthenticatedRequest, res) => {
  try {
    const { userId } = req.params;
    
    const result = await userService.activateUser(userId);
    
    return res.status(result.success ? 200 : 404).json({
      success: result.success,
      message: result.message,
      actionedBy: req.user?.email,
      timestamp: new Date(),
    });
  } catch (error) {
    console.error('Admin activate user error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error activating user',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// Conversation Review (NEW - replacing license management)
router.get('/conversations', async (req: AuthenticatedRequest, res) => {
  try {
    const limit = parseInt(req.query.limit as string) || 50;
    const status = req.query.status as string;
    
    // For admin, we need to get all conversations (not filtered by user)
    const snapshot = await chatService.getAllConversations?.(limit) || [];
    
    return res.status(200).json({
      success: true,
      data: snapshot,
      count: snapshot.length,
      requestedBy: req.user?.email,
    });
  } catch (error) {
    console.error('Admin get conversations error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error fetching conversations',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// Get conversation analytics
router.get('/conversations/analytics', async (req: AuthenticatedRequest, res) => {
  try {
    // This would typically involve aggregation queries
    const analytics = {
      totalConversations: 0,
      activeConversations: 0,
      resolvedConversations: 0,
      averageMessagesPerConversation: 0,
      popularPersonas: [],
    };

    return res.status(200).json({
      success: true,
      data: analytics,
      requestedBy: req.user?.email,
    });
  } catch (error) {
    console.error('Admin get conversation analytics error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error fetching conversation analytics',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// Flag conversation for review
router.post('/conversations/:conversationId/flag', async (req: AuthenticatedRequest, res) => {
  try {
    const { conversationId } = req.params;
    const { reason } = req.body;

    if (!reason) {
      return res.status(400).json({
        success: false,
        error: 'Flag reason is required',
      });
    }

    // Implementation would update conversation status to 'flagged'
    // This is a placeholder for the actual implementation
    
    return res.status(200).json({
      success: true,
      message: `Conversation ${conversationId} flagged for review`,
      reason,
      flaggedBy: req.user?.email,
      timestamp: new Date(),
    });
  } catch (error) {
    console.error('Admin flag conversation error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error flagging conversation',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// AI Persona Management (NEW)
router.get('/personas', async (req: AuthenticatedRequest, res) => {
  try {
    const personas = await aiPersonaService.getAllPersonas();

    return res.status(200).json({
      success: true,
      data: personas,
      count: personas.length,
      requestedBy: req.user?.email,
    });
  } catch (error) {
    console.error('Admin get personas error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error fetching personas',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// Persona statistics
router.get('/personas/stats', async (req: AuthenticatedRequest, res) => {
  try {
    const stats = await aiPersonaService.getPersonaStatistics();

    return res.status(200).json({
      success: true,
      data: stats,
      requestedBy: req.user?.email,
    });
  } catch (error) {
    console.error('Admin get persona stats error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error fetching persona statistics',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// Updated Dashboard (NEW - replacing license-focused dashboard)
router.get('/dashboard', async (req: AuthenticatedRequest, res) => {
  try {
    // Get user statistics
    const userStats = await userService.getUserStatistics();
    
    // Get persona statistics
    const personaStats = await aiPersonaService.getPersonaStatistics();

    // Get conversation statistics (placeholder)
    const conversationStats = {
      totalConversations: 0,
      activeConversations: 0,
      resolvedConversations: 0,
      averageMessagesPerConversation: 0,
    };

    const dashboardData = {
      users: userStats,
      personas: personaStats,
      conversations: conversationStats,
      system: {
        adminEmail: req.user?.email,
        generatedAt: new Date(),
        version: '2.0.0',
        features: {
          aiChat: true,
          personaManagement: true,
          userManagement: true,
          conversationReview: true,
        },
      },
    };

    return res.status(200).json({
      success: true,
      data: dashboardData,
    });
  } catch (error) {
    console.error('Admin dashboard error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error generating dashboard',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// System Health (updated)
router.get('/health', async (req: AuthenticatedRequest, res) => {
  try {
    const health = {
      status: 'healthy',
      timestamp: new Date(),
      services: {
        database: 'connected',
        authentication: 'operational',
        ai: process.env.EXTERNAL_AI_API_KEY ? 'configured' : 'mock-mode',
        chat: 'operational',
        personas: 'operational',
      },
      version: '2.0.0',
      environment: process.env.NODE_ENV || 'development',
      uptime: process.uptime(),
      memory: process.memoryUsage(),
    };

    return res.status(200).json({
      success: true,
      data: health,
    });
  } catch (error) {
    console.error('Admin health check error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error during health check',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// REMOVED: All license-related endpoints
// - GET /licenses
// - POST /licenses/:licenseId/reset-counter

export default router;