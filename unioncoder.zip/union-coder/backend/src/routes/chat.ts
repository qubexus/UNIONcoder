import { Router } from 'express';
import { ChatService } from '../services/chatService';
import { authenticateUser, AuthenticatedRequest } from '../middleware/rbac';
import { CreateConversationSchema, SendMessageSchema } from '../validation/schemas';

const router = Router();
const chatService = new ChatService();

// All chat routes require authentication
router.use(authenticateUser);

// Create a new conversation
router.post('/conversations', async (req: AuthenticatedRequest, res) => {
  try {
    if (!req.user?.uid) {
      return res.status(401).json({
        error: 'User authentication required',
      });
    }

    // Validate input
    const validationResult = CreateConversationSchema.safeParse(req.body);
    
    if (!validationResult.success) {
      return res.status(400).json({
        error: 'Validation failed',
        details: validationResult.error.errors,
      });
    }

    const conversation = await chatService.createConversation(req.user.uid, validationResult.data);

    return res.status(201).json({
      success: true,
      message: 'Conversation created successfully',
      data: conversation,
    });
  } catch (error) {
    console.error('Create conversation error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error creating conversation',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// Send a message in a conversation
router.post('/messages', async (req: AuthenticatedRequest, res) => {
  try {
    if (!req.user?.uid) {
      return res.status(401).json({
        error: 'User authentication required',
      });
    }

    // Validate input
    const validationResult = SendMessageSchema.safeParse(req.body);
    
    if (!validationResult.success) {
      return res.status(400).json({
        error: 'Validation failed',
        details: validationResult.error.errors,
      });
    }

    const response = await chatService.sendMessage(req.user.uid, validationResult.data);

    return res.status(200).json({
      success: true,
      message: 'Message sent successfully',
      data: response,
    });
  } catch (error) {
    console.error('Send message error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error sending message',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// Get all conversations for the authenticated user
router.get('/conversations', async (req: AuthenticatedRequest, res) => {
  try {
    if (!req.user?.uid) {
      return res.status(401).json({
        error: 'User authentication required',
      });
    }

    const limit = parseInt(req.query.limit as string) || 20;
    const conversations = await chatService.getConversations(req.user.uid, limit);

    return res.status(200).json({
      success: true,
      data: conversations,
      count: conversations.length,
    });
  } catch (error) {
    console.error('Get conversations error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error fetching conversations',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// Get a specific conversation by ID
router.get('/conversations/:conversationId', async (req: AuthenticatedRequest, res) => {
  try {
    if (!req.user?.uid) {
      return res.status(401).json({
        error: 'User authentication required',
      });
    }

    const { conversationId } = req.params;
    
    const conversation = await chatService.getConversationById(req.user.uid, conversationId);
    
    if (!conversation) {
      return res.status(404).json({
        success: false,
        error: 'Conversation not found',
      });
    }

    return res.status(200).json({
      success: true,
      data: conversation,
    });
  } catch (error) {
    console.error('Get conversation error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error fetching conversation',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// Delete a conversation
router.delete('/conversations/:conversationId', async (req: AuthenticatedRequest, res) => {
  try {
    if (!req.user?.uid) {
      return res.status(401).json({
        error: 'User authentication required',
      });
    }

    const { conversationId } = req.params;
    
    const result = await chatService.deleteConversation(req.user.uid, conversationId);

    return res.status(result.success ? 200 : 404).json({
      success: result.success,
      message: result.message,
    });
  } catch (error) {
    console.error('Delete conversation error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error deleting conversation',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

export default router;