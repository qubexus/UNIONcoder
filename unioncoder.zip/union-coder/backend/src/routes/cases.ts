import { Router } from 'express';
import { CaseService } from '../services/caseService';
import { authenticateUser, requireAgent, AuthenticatedRequest } from '../middleware/rbac';
import { CaseCreateSchema, CaseUpdateSchema } from '../validation/schemas';

const router = Router();
const caseService = new CaseService();

// Create a new case (protected for agents)
router.post('/', authenticateUser, requireAgent, async (req: AuthenticatedRequest, res) => {
  try {
    // Validate input
    const validationResult = CaseCreateSchema.safeParse(req.body);
    
    if (!validationResult.success) {
      return res.status(400).json({
        error: 'Validation failed',
        details: validationResult.error.errors,
      });
    }

    if (!req.user?.uid) {
      return res.status(401).json({
        error: 'User authentication required',
      });
    }

    const newCase = await caseService.createCase(validationResult.data, req.user.uid);

    return res.status(201).json({
      success: true,
      message: 'Case created successfully',
      data: newCase,
    });
  } catch (error) {
    console.error('Create case error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error creating case',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// Get all cases for the authenticated agent
router.get('/my-cases', authenticateUser, requireAgent, async (req: AuthenticatedRequest, res) => {
  try {
    if (!req.user?.uid) {
      return res.status(401).json({
        error: 'User authentication required',
      });
    }

    const cases = await caseService.getCasesByAgent(req.user.uid);

    return res.status(200).json({
      success: true,
      data: cases,
      count: cases.length,
    });
  } catch (error) {
    console.error('Get agent cases error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error fetching cases',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// Get case by ID
router.get('/:caseId', authenticateUser, requireAgent, async (req: AuthenticatedRequest, res) => {
  try {
    const { caseId } = req.params;
    
    const caseData = await caseService.getCaseById(caseId);
    
    if (!caseData) {
      return res.status(404).json({
        success: false,
        error: 'Case not found',
      });
    }

    // Check if the case belongs to the authenticated agent (or if admin)
    if (req.user?.role !== 'admin' && caseData.assignedAgentId !== req.user?.uid) {
      return res.status(403).json({
        success: false,
        error: 'Access denied: You can only view your own cases',
      });
    }

    return res.status(200).json({
      success: true,
      data: caseData,
    });
  } catch (error) {
    console.error('Get case error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error fetching case',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// Update case
router.put('/:caseId', authenticateUser, requireAgent, async (req: AuthenticatedRequest, res) => {
  try {
    const { caseId } = req.params;
    
    // Validate input
    const validationResult = CaseUpdateSchema.safeParse(req.body);
    
    if (!validationResult.success) {
      return res.status(400).json({
        error: 'Validation failed',
        details: validationResult.error.errors,
      });
    }

    // First check if case exists and belongs to the agent
    const existingCase = await caseService.getCaseById(caseId);
    
    if (!existingCase) {
      return res.status(404).json({
        success: false,
        error: 'Case not found',
      });
    }

    if (req.user?.role !== 'admin' && existingCase.assignedAgentId !== req.user?.uid) {
      return res.status(403).json({
        success: false,
        error: 'Access denied: You can only update your own cases',
      });
    }

    const updatedCase = await caseService.updateCase(caseId, validationResult.data);

    return res.status(200).json({
      success: true,
      message: 'Case updated successfully',
      data: updatedCase,
    });
  } catch (error) {
    console.error('Update case error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error updating case',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// Delete case
router.delete('/:caseId', authenticateUser, requireAgent, async (req: AuthenticatedRequest, res) => {
  try {
    const { caseId } = req.params;
    
    // First check if case exists and belongs to the agent
    const existingCase = await caseService.getCaseById(caseId);
    
    if (!existingCase) {
      return res.status(404).json({
        success: false,
        error: 'Case not found',
      });
    }

    if (req.user?.role !== 'admin' && existingCase.assignedAgentId !== req.user?.uid) {
      return res.status(403).json({
        success: false,
        error: 'Access denied: You can only delete your own cases',
      });
    }

    const result = await caseService.deleteCase(caseId);

    return res.status(result.success ? 200 : 404).json({
      success: result.success,
      message: result.message,
    });
  } catch (error) {
    console.error('Delete case error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error deleting case',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// Get cases by status
router.get('/status/:status', authenticateUser, requireAgent, async (req: AuthenticatedRequest, res) => {
  try {
    const { status } = req.params;
    
    const validStatuses = ['pending', 'in-progress', 'completed', 'high-priority'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid status. Valid statuses: ' + validStatuses.join(', '),
      });
    }

    const cases = await caseService.getCasesByStatus(status as any);

    // Filter cases based on user role
    let filteredCases = cases;
    if (req.user?.role !== 'admin') {
      filteredCases = cases.filter(c => c.assignedAgentId === req.user?.uid);
    }

    return res.status(200).json({
      success: true,
      data: filteredCases,
      count: filteredCases.length,
      status: status,
    });
  } catch (error) {
    console.error('Get cases by status error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error fetching cases by status',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

export default router;