import { Router } from 'express';
import { UserService } from '../services/userService';
import { authenticateUser, AuthenticatedRequest } from '../middleware/rbac';
import { UserCreateSchema, UserUpdateSchema } from '../validation/schemas';

const router = Router();
const userService = new UserService();

// All user routes require authentication
router.use(authenticateUser);

// Get current user profile
router.get('/profile', async (req: AuthenticatedRequest, res) => {
  try {
    if (!req.user?.uid) {
      return res.status(401).json({
        error: 'User authentication required',
      });
    }

    const user = await userService.getUserByFirebaseUid(req.user.uid);
    
    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User profile not found',
      });
    }

    return res.status(200).json({
      success: true,
      data: user,
    });
  } catch (error) {
    console.error('Get user profile error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error fetching user profile',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// Create user profile (for first-time login)
router.post('/profile', async (req: AuthenticatedRequest, res) => {
  try {
    if (!req.user?.uid) {
      return res.status(401).json({
        error: 'User authentication required',
      });
    }

    // Check if user already exists
    const existingUser = await userService.getUserByFirebaseUid(req.user.uid);
    if (existingUser) {
      return res.status(409).json({
        success: false,
        error: 'User profile already exists',
        message: 'Use PUT /profile to update existing profile',
      });
    }

    // Validate input
    const validationResult = UserCreateSchema.safeParse({
      ...req.body,
      email: req.user.email, // Use email from Firebase auth
    });
    
    if (!validationResult.success) {
      return res.status(400).json({
        error: 'Validation failed',
        details: validationResult.error.errors,
      });
    }

    const newUser = await userService.createUser(validationResult.data, req.user.uid);

    return res.status(201).json({
      success: true,
      message: 'User profile created successfully',
      data: newUser,
    });
  } catch (error) {
    console.error('Create user profile error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error creating user profile',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// Update current user profile
router.put('/profile', async (req: AuthenticatedRequest, res) => {
  try {
    if (!req.user?.uid) {
      return res.status(401).json({
        error: 'User authentication required',
      });
    }

    // Get existing user
    const existingUser = await userService.getUserByFirebaseUid(req.user.uid);
    if (!existingUser) {
      return res.status(404).json({
        success: false,
        error: 'User profile not found',
        message: 'Create a profile first using POST /profile',
      });
    }

    // Validate input
    const validationResult = UserUpdateSchema.safeParse(req.body);
    
    if (!validationResult.success) {
      return res.status(400).json({
        error: 'Validation failed',
        details: validationResult.error.errors,
      });
    }

    const updatedUser = await userService.updateUser(existingUser.userId, validationResult.data);

    return res.status(200).json({
      success: true,
      message: 'User profile updated successfully',
      data: updatedUser,
    });
  } catch (error) {
    console.error('Update user profile error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error updating user profile',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// Update last login (called after successful login)
router.post('/login', async (req: AuthenticatedRequest, res) => {
  try {
    if (!req.user?.uid) {
      return res.status(401).json({
        error: 'User authentication required',
      });
    }

    const user = await userService.getUserByFirebaseUid(req.user.uid);
    
    if (user) {
      await userService.updateLastLogin(user.userId);
    }

    return res.status(200).json({
      success: true,
      message: 'Login recorded successfully',
      data: {
        userId: req.user.uid,
        email: req.user.email,
        hasProfile: !!user,
      },
    });
  } catch (error) {
    console.error('Login tracking error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error during login tracking',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// Get user statistics (for current user's dashboard)
router.get('/stats', async (req: AuthenticatedRequest, res) => {
  try {
    if (!req.user?.uid) {
      return res.status(401).json({
        error: 'User authentication required',
      });
    }

    const user = await userService.getUserByFirebaseUid(req.user.uid);
    
    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User profile not found',
      });
    }

    // Get user's conversation statistics
    const { ConversationService } = await import('../services/chatService');
    const chatService = new ConversationService();
    const conversations = await chatService.getConversations(user.userId, 100);

    const stats = {
      totalConversations: conversations.length,
      activeConversations: conversations.filter(c => c.status === 'active').length,
      resolvedConversations: conversations.filter(c => c.isResolved).length,
      memberSince: user.createdAt,
      lastLogin: user.lastLoginAt,
      profileCompleteness: calculateProfileCompleteness(user),
    };

    return res.status(200).json({
      success: true,
      data: stats,
    });
  } catch (error) {
    console.error('Get user stats error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error fetching user statistics',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

export default router;

// Helper function to calculate profile completeness
function calculateProfileCompleteness(user: any): number {
  const fields = ['displayName', 'currentEmployer', 'department', 'jobTitle'];
  const completedFields = fields.filter(field => user[field] && user[field].trim() !== '').length;
  return Math.round((completedFields / fields.length) * 100);
}