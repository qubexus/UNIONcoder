import { Router } from 'express';
import { AIService } from '../services/aiService';
import { authenticateUser, requireAgent, AuthenticatedRequest } from '../middleware/rbac';
import { AISummarySchema } from '../validation/schemas';

const router = Router();
const aiService = new AIService();

// Generate case summary using AI
router.post('/case-summary', authenticateUser, requireAgent, async (req: AuthenticatedRequest, res) => {
  try {
    // Validate input
    const validationResult = AISummarySchema.safeParse(req.body);
    
    if (!validationResult.success) {
      return res.status(400).json({
        error: 'Validation failed',
        details: validationResult.error.errors,
      });
    }

    const { summary } = await aiService.generateCaseSummary(validationResult.data);

    return res.status(200).json({
      success: true,
      data: {
        summary,
        processedAt: new Date(),
        originalDescription: validationResult.data.caseDescription,
      },
    });
  } catch (error) {
    console.error('AI summary error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error generating AI summary',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// Analyze case sentiment
router.post('/sentiment-analysis', authenticateUser, requireAgent, async (req: AuthenticatedRequest, res) => {
  try {
    const { caseDescription } = req.body;

    if (!caseDescription || typeof caseDescription !== 'string') {
      return res.status(400).json({
        error: 'Case description is required and must be a string',
      });
    }

    const sentiment = await aiService.analyzeCaseSentiment(caseDescription);

    return res.status(200).json({
      success: true,
      data: {
        ...sentiment,
        analyzedAt: new Date(),
        textLength: caseDescription.length,
      },
    });
  } catch (error) {
    console.error('Sentiment analysis error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error during sentiment analysis',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// Get AI service status
router.get('/status', authenticateUser, requireAgent, async (req: AuthenticatedRequest, res) => {
  try {
    const hasApiKey = !!(process.env.EXTERNAL_AI_API_KEY);
    const apiUrl = process.env.EXTERNAL_AI_BASE_URL || 'https://api.anthropic.com';

    return res.status(200).json({
      success: true,
      data: {
        service: 'AI Integration Service',
        status: hasApiKey ? 'configured' : 'mock-mode',
        apiUrl,
        features: {
          caseSummary: true,
          sentimentAnalysis: true,
          externalIntegration: hasApiKey,
        },
      },
    });
  } catch (error) {
    console.error('AI status check error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error checking AI service status',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

export default router;