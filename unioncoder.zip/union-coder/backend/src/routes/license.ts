import { Router } from 'express';
import { LicenseService } from '../services/licenseService';
import { authenticateUser, requireAgent, AuthenticatedRequest } from '../middleware/rbac';
import { LicenseUpdateSchema } from '../validation/schemas';

const router = Router();
const licenseService = new LicenseService();

// Update license assignment (protected for agents)
router.post('/update-assignment', authenticateUser, requireAgent, async (req: AuthenticatedRequest, res) => {
  try {
    // Validate input
    const validationResult = LicenseUpdateSchema.safeParse(req.body);
    
    if (!validationResult.success) {
      return res.status(400).json({
        error: 'Validation failed',
        details: validationResult.error.errors,
      });
    }

    const result = await licenseService.updateLicenseAssignment(validationResult.data);

    if (result.success) {
      return res.status(200).json({
        success: true,
        message: result.message,
        remainingChanges: result.remainingChanges,
      });
    } else {
      // Handle 403 for exhausted changes
      if (result.message.includes('exhausted')) {
        return res.status(403).json({
          success: false,
          error: 'License change limit exceeded',
          message: result.message,
          remainingChanges: result.remainingChanges,
        });
      }
      
      return res.status(400).json({
        success: false,
        error: result.message,
      });
    }
  } catch (error) {
    console.error('License update error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error during license update',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// Get license by ID (protected for agents)
router.get('/:licenseId', authenticateUser, requireAgent, async (req: AuthenticatedRequest, res) => {
  try {
    const { licenseId } = req.params;
    
    const license = await licenseService.getLicenseById(licenseId);
    
    if (!license) {
      return res.status(404).json({
        success: false,
        error: 'License not found',
      });
    }

    return res.status(200).json({
      success: true,
      data: license,
    });
  } catch (error) {
    console.error('Get license error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error fetching license',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

// Reset license counter (admin only)
router.post('/:licenseId/reset-counter', authenticateUser, requireAgent, async (req: AuthenticatedRequest, res) => {
  try {
    const { licenseId } = req.params;
    
    const result = await licenseService.resetLicenseCounter(licenseId);
    
    return res.status(result.success ? 200 : 404).json({
      success: result.success,
      message: result.message,
    });
  } catch (error) {
    console.error('Reset license counter error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal server error resetting license counter',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

export default router;