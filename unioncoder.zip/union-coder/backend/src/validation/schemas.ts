import { z } from 'zod';

// REMOVED: License-related schemas (LicenseUpdateSchema, etc.)

// NEW: AI Chat-focused validation schemas
export const CreateConversationSchema = z.object({
  personaId: z.string().min(1, "Persona ID is required"),
  initialMessage: z.string().min(1, "Initial message is required").max(1000, "Message too long"),
});

export const SendMessageSchema = z.object({
  conversationId: z.string().min(1, "Conversation ID is required"),
  content: z.string().min(1, "Message content is required").max(1000, "Message too long"),
});

export const UserCreateSchema = z.object({
  email: z.string().email("Valid email is required"),
  displayName: z.string().min(1, "Display name is required").max(50, "Name too long"),
  currentEmployer: z.string().optional(),
  department: z.string().optional(),
  jobTitle: z.string().optional(),
});

export const UserUpdateSchema = z.object({
  displayName: z.string().min(1, "Display name is required").max(50, "Name too long").optional(),
  currentEmployer: z.string().optional(),
  department: z.string().optional(),
  jobTitle: z.string().optional(),
  isActive: z.boolean().optional(),
});

export const AIPersonaCreateSchema = z.object({
  name: z.string().min(1, "Persona name is required").max(50, "Name too long"),
  title: z.string().min(1, "Persona title is required").max(100, "Title too long"),
  specialization: z.string().min(1, "Specialization is required").max(100, "Specialization too long"),
  description: z.string().min(1, "Description is required").max(500, "Description too long"),
  avatar: z.string().min(1, "Avatar is required").max(10, "Avatar should be emoji or short identifier"),
  systemPrompt: z.string().min(10, "System prompt must be at least 10 characters").max(2000, "System prompt too long"),
  isActive: z.boolean().default(true),
  sortOrder: z.number().int().min(0).default(0),
});

export const AIPersonaUpdateSchema = z.object({
  name: z.string().min(1, "Persona name is required").max(50, "Name too long").optional(),
  title: z.string().min(1, "Persona title is required").max(100, "Title too long").optional(),
  specialization: z.string().min(1, "Specialization is required").max(100, "Specialization too long").optional(),
  description: z.string().min(1, "Description is required").max(500, "Description too long").optional(),
  avatar: z.string().min(1, "Avatar is required").max(10, "Avatar should be emoji or short identifier").optional(),
  systemPrompt: z.string().min(10, "System prompt must be at least 10 characters").max(2000, "System prompt too long").optional(),
  isActive: z.boolean().optional(),
  sortOrder: z.number().int().min(0).optional(),
});

// Keep only useful legacy schemas
export const AISummarySchema = z.object({
  caseDescription: z.string().min(1, "Case description is required"),
  maxLength: z.number().min(1).max(100).optional().default(3),
});

// Type exports
export type CreateConversationInput = z.infer<typeof CreateConversationSchema>;
export type SendMessageInput = z.infer<typeof SendMessageSchema>;
export type UserCreateInput = z.infer<typeof UserCreateSchema>;
export type UserUpdateInput = z.infer<typeof UserUpdateSchema>;
export type AIPersonaCreateInput = z.infer<typeof AIPersonaCreateSchema>;
export type AIPersonaUpdateInput = z.infer<typeof AIPersonaUpdateSchema>;
export type AISummaryInput = z.infer<typeof AISummarySchema>;