import { db } from '../config/firebase';
import { 
  Conversation, 
  Message, 
  CreateConversationRequest, 
  SendMessageRequest, 
  ChatResponse,
  AIPersona 
} from '../types';
import { CreateConversationInput, SendMessageInput } from '../validation/schemas';
import { AIService } from './aiService';

export class ChatService {
  private readonly conversationsCollection = 'conversations';
  private readonly usersCollection = 'users';
  private readonly personasCollection = 'ai_personas';
  private aiService: AIService;

  constructor() {
    this.aiService = new AIService();
  }

  async createConversation(userId: string, data: CreateConversationInput): Promise<Conversation> {
    try {
      // Verify persona exists and is active
      const personaDoc = await db.collection(this.personasCollection).doc(data.personaId).get();
      if (!personaDoc.exists || !personaDoc.data()?.isActive) {
        throw new Error('Persona not found or inactive');
      }

      // Generate AI response for initial message
      const aiResponse = await this.generateAIResponse(
        data.initialMessage,
        personaDoc.data() as AIPersona,
        []
      );

      // Create conversation with initial messages
      const userMessage: Message = {
        messageId: this.generateMessageId(),
        sender: 'user',
        content: data.initialMessage,
        timestamp: new Date(),
      };

      const aiMessage: Message = {
        messageId: this.generateMessageId(),
        sender: 'ai',
        content: aiResponse.content,
        timestamp: new Date(),
        metadata: aiResponse.metadata,
      };

      const conversationData: Omit<Conversation, 'conversationId'> = {
        userId,
        personaId: data.personaId,
        title: this.generateConversationTitle(data.initialMessage),
        status: 'active',
        messages: [userMessage, aiMessage],
        startedAt: new Date(),
        lastMessageAt: new Date(),
        isResolved: false,
        category: aiResponse.category,
        tags: this.extractTags(data.initialMessage),
      };

      const docRef = await db.collection(this.conversationsCollection).add(conversationData);
      
      return {
        conversationId: docRef.id,
        ...conversationData,
      };
    } catch (error) {
      console.error('Error creating conversation:', error);
      throw new Error(`Failed to create conversation: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async sendMessage(userId: string, data: SendMessageInput): Promise<ChatResponse> {
    try {
      const conversationRef = db.collection(this.conversationsCollection).doc(data.conversationId);
      const conversationDoc = await conversationRef.get();

      if (!conversationDoc.exists) {
        throw new Error('Conversation not found');
      }

      const conversation = conversationDoc.data() as Conversation;

      // Verify user owns this conversation
      if (conversation.userId !== userId) {
        throw new Error('Access denied: You can only send messages to your own conversations');
      }

      // Get persona for AI response
      const personaDoc = await db.collection(this.personasCollection).doc(conversation.personaId).get();
      if (!personaDoc.exists) {
        throw new Error('Persona not found');
      }

      // Add user message
      const userMessage: Message = {
        messageId: this.generateMessageId(),
        sender: 'user',
        content: data.content,
        timestamp: new Date(),
      };

      // Generate AI response
      const aiResponse = await this.generateAIResponse(
        data.content,
        personaDoc.data() as AIPersona,
        conversation.messages
      );

      const aiMessage: Message = {
        messageId: this.generateMessageId(),
        sender: 'ai',
        content: aiResponse.content,
        timestamp: new Date(),
        metadata: aiResponse.metadata,
      };

      // Update conversation with new messages
      const updatedMessages = [...conversation.messages, userMessage, aiMessage];
      
      await conversationRef.update({
        messages: updatedMessages,
        lastMessageAt: new Date(),
        category: aiResponse.category || conversation.category,
        tags: [...new Set([...conversation.tags, ...this.extractTags(data.content)])],
      });

      return {
        conversationId: data.conversationId,
        message: aiMessage,
        suggestions: aiResponse.suggestions,
        category: aiResponse.category,
      };
    } catch (error) {
      console.error('Error sending message:', error);
      throw new Error(`Failed to send message: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async getConversations(userId: string, limit: number = 20): Promise<Conversation[]> {
    try {
      const snapshot = await db.collection(this.conversationsCollection)
        .where('userId', '==', userId)
        .orderBy('lastMessageAt', 'desc')
        .limit(limit)
        .get();

      return snapshot.docs.map(doc => ({
        conversationId: doc.id,
        ...doc.data(),
      })) as Conversation[];
    } catch (error) {
      console.error('Error fetching conversations:', error);
      throw new Error(`Failed to fetch conversations: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async getConversationById(userId: string, conversationId: string): Promise<Conversation | null> {
    try {
      const conversationDoc = await db.collection(this.conversationsCollection).doc(conversationId).get();
      
      if (!conversationDoc.exists) {
        return null;
      }

      const conversation = {
        conversationId: conversationDoc.id,
        ...conversationDoc.data(),
      } as Conversation;

      // Verify user owns this conversation
      if (conversation.userId !== userId) {
        throw new Error('Access denied: You can only view your own conversations');
      }

      return conversation;
    } catch (error) {
      console.error('Error fetching conversation:', error);
      throw new Error(`Failed to fetch conversation: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async deleteConversation(userId: string, conversationId: string): Promise<{ success: boolean; message: string }> {
    try {
      const conversationRef = db.collection(this.conversationsCollection).doc(conversationId);
      const conversationDoc = await conversationRef.get();

      if (!conversationDoc.exists) {
        return {
          success: false,
          message: 'Conversation not found',
        };
      }

      const conversation = conversationDoc.data() as Conversation;

      // Verify user owns this conversation
      if (conversation.userId !== userId) {
        throw new Error('Access denied: You can only delete your own conversations');
      }

      await conversationRef.delete();

      return {
        success: true,
        message: `Conversation ${conversationId} deleted successfully`,
      };
    } catch (error) {
      console.error('Error deleting conversation:', error);
      throw new Error(`Failed to delete conversation: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  private async generateAIResponse(
    userMessage: string,
    persona: AIPersona,
    conversationHistory: Message[]
  ): Promise<{ content: string; metadata?: any; suggestions?: string[]; category?: string }> {
    try {
      // Build conversation context
      const contextMessages = conversationHistory.slice(-6); // Last 6 messages for context
      const conversationContext = contextMessages
        .map(msg => `${msg.sender.toUpperCase()}: ${msg.content}`)
        .join('\n');

      // Create prompt with persona system prompt and context
      const fullPrompt = `${persona.systemPrompt}

Previous conversation:
${conversationContext}

USER: ${userMessage}

${persona.name}:`;

      const startTime = Date.now();
      const response = await this.aiService.generateCaseSummary({
        caseDescription: fullPrompt,
        maxLength: 10, // Allow longer responses for chat
      });
      const processingTime = Date.now() - startTime;

      return {
        content: response.summary,
        metadata: {
          processingTime,
          aiModel: 'claude-3-sonnet',
          tokensUsed: Math.floor(response.summary.length * 1.3), // Rough estimate
          personaId: persona.personaId,
          personaName: persona.name,
        },
        suggestions: this.generateFollowUpSuggestions(userMessage, response.summary),
        category: this.categorizeMessage(userMessage),
      };
    } catch (error) {
      console.error('Error generating AI response:', error);
      return {
        content: `I'm sorry, I'm having trouble responding right now. As your ${persona.title}, I want to help you with ${persona.specialization.toLowerCase()}. Could you please rephrase your question or try again in a moment?`,
        metadata: {
          processingTime: 0,
          error: 'AI service unavailable',
        },
      };
    }
  }

  private generateFollowUpSuggestions(userMessage: string, aiResponse: string): string[] {
    const suggestions = [];
    
    if (userMessage.toLowerCase().includes('contract') || userMessage.toLowerCase().includes('agreement')) {
      suggestions.push('What are my contract violation rights?', 'How do I report a breach?');
    }
    
    if (userMessage.toLowerCase().includes('wage') || userMessage.toLowerCase().includes('pay')) {
      suggestions.push('What constitutes unpaid wages?', 'How do I file a wage claim?');
    }
    
    if (userMessage.toLowerCase().includes('termination') || userMessage.toLowerCase().includes('fired')) {
      suggestions.push('What is wrongful termination?', 'What are my severance rights?');
    }

    if (suggestions.length === 0) {
      suggestions.push('Can you explain my rights in this situation?', 'What steps should I take next?');
    }

    return suggestions.slice(0, 3);
  }

  private categorizeMessage(message: string): string {
    const lowerMessage = message.toLowerCase();
    
    if (lowerMessage.includes('contract') || lowerMessage.includes('agreement')) {
      return 'Contract Dispute';
    }
    if (lowerMessage.includes('wage') || lowerMessage.includes('pay') || lowerMessage.includes('salary')) {
      return 'Compensation';
    }
    if (lowerMessage.includes('termination') || lowerMessage.includes('fired')) {
      return 'Termination';
    }
    if (lowerMessage.includes('harassment') || lowerMessage.includes('discrimination')) {
      return 'Workplace Harassment';
    }
    if (lowerMessage.includes('safety') || lowerMessage.includes('hazard')) {
      return 'Workplace Safety';
    }
    
    return 'General Inquiry';
  }

  private extractTags(message: string): string[] {
    const tags: string[] = [];
    const lowerMessage = message.toLowerCase();
    
    const tagKeywords = {
      'urgent': ['urgent', 'emergency', 'immediate'],
      'legal': ['legal', 'lawyer', 'attorney', 'sue'],
      'contract': ['contract', 'agreement', 'clause'],
      'termination': ['fired', 'terminated', 'laid off'],
      'harassment': ['harassment', 'bullying', 'discrimination'],
      'wage': ['wage', 'salary', 'pay', 'compensation'],
      'benefits': ['benefits', 'healthcare', 'insurance', 'retirement'],
      'safety': ['safety', 'hazard', 'injury', 'osha'],
    };
    
    for (const [tag, keywords] of Object.entries(tagKeywords)) {
      if (keywords.some(keyword => lowerMessage.includes(keyword))) {
        tags.push(tag);
      }
    }
    
    return tags;
  }

  private generateConversationTitle(message: string): string {
    const words = message.split(' ').slice(0, 5).join(' ');
    return words.length > 50 ? words.substring(0, 47) + '...' : words;
  }

  private generateMessageId(): string {
    return `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }
}