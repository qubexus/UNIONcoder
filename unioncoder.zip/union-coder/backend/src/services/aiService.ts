import { AISummaryInput } from '../validation/schemas';

export class AIService {
  private readonly apiKey: string;
  private readonly baseUrl: string;

  constructor() {
    this.apiKey = process.env.EXTERNAL_AI_API_KEY || '';
    this.baseUrl = process.env.EXTERNAL_AI_BASE_URL || 'https://api.anthropic.com';
    
    if (!this.apiKey) {
      console.warn('AI Service: No API key provided. Using mock responses.');
    }
  }

  async generateCaseSummary(input: AISummaryInput): Promise<{ summary: string }> {
    const { caseDescription, maxLength = 3 } = input;

    // If no API key is configured, return a mock response
    if (!this.apiKey) {
      return this.generateMockSummary(caseDescription, maxLength);
    }

    try {
      // Placeholder for Anthropic Claude API integration
      const prompt = `Please provide a concise summary (maximum ${maxLength} sentences) of the following union case description:

${caseDescription}

Summary:`;

      const response = await this.callClaudeAPI(prompt);
      
      return {
        summary: response.trim(),
      };
    } catch (error) {
      console.error('AI Service Error:', error);
      // Fallback to mock response if AI service fails
      return this.generateMockSummary(caseDescription, maxLength);
    }
  }

  private async callClaudeAPI(prompt: string): Promise<string> {
    // This is a placeholder implementation
    // In production, this would make an actual API call to Claude or GPT-4
    
    const mockResponse = `Case involves workplace dispute requiring union intervention. Key issues include contract violations and employee rights. Resolution requires negotiation with management.`;
    
    return mockResponse;
  }

  private generateMockSummary(caseDescription: string, maxLength: number): { summary: string } {
    // Simple keyword-based mock summary generation
    const keywords = caseDescription.toLowerCase().split(' ');
    let summary = 'Union case';
    
    if (keywords.includes('wage') || keywords.includes('salary')) {
      summary += ' involving compensation issues';
    }
    if (keywords.includes('termination') || keywords.includes('fired')) {
      summary += ' regarding employment termination';
    }
    if (keywords.includes('safety') || keywords.includes('hazard')) {
      summary += ' related to workplace safety';
    }
    if (keywords.includes('contract') || keywords.includes('agreement')) {
      summary += ' concerning contract disputes';
    }
    
    summary += '. Requires union representation and negotiation.';
    
    // Ensure it doesn't exceed the maximum sentence count
    const sentences = summary.split('.').filter(s => s.trim());
    if (sentences.length > maxLength) {
      summary = sentences.slice(0, maxLength).join('.') + '.';
    }
    
    return { summary };
  }

  async analyzeCaseSentiment(caseDescription: string): Promise<{ sentiment: 'positive' | 'negative' | 'neutral'; confidence: number }> {
    // Placeholder implementation for sentiment analysis
    const negativeWords = ['fired', 'terminated', 'unfair', 'discrimination', 'harassment'];
    const positiveWords = ['promotion', 'raise', 'benefit', 'improvement', 'agreement'];
    
    const words = caseDescription.toLowerCase().split(' ');
    const negativeCount = words.filter(word => negativeWords.includes(word)).length;
    const positiveCount = words.filter(word => positiveWords.includes(word)).length;
    
    if (negativeCount > positiveCount) {
      return { sentiment: 'negative', confidence: Math.min(0.9, 0.5 + negativeCount * 0.1) };
    } else if (positiveCount > negativeCount) {
      return { sentiment: 'positive', confidence: Math.min(0.9, 0.5 + positiveCount * 0.1) };
    } else {
      return { sentiment: 'neutral', confidence: 0.7 };
    }
  }
}