import { db, auth } from '../config/firebase';
import { User, UserCreateInput, UserUpdateInput } from '../types';

export class UserService {
  private readonly collection = 'users';

  async createUser(userData: UserCreateInput, firebaseUid: string): Promise<User> {
    try {
      const existingUser = await this.getUserByFirebaseUid(firebaseUid);
      if (existingUser) {
        throw new Error('User already exists');
      }

      const newUser: Omit<User, 'userId'> = {
        email: userData.email,
        displayName: userData.displayName,
        currentEmployer: userData.currentEmployer,
        department: userData.department,
        jobTitle: userData.jobTitle,
        joinDate: new Date(),
        lastLoginAt: new Date(),
        isActive: true,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      const docRef = await db.collection(this.collection).add(newUser);
      
      return {
        userId: docRef.id,
        ...newUser,
      };
    } catch (error) {
      console.error('Error creating user:', error);
      throw new Error(`Failed to create user: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async getUserById(userId: string): Promise<User | null> {
    try {
      const userDoc = await db.collection(this.collection).doc(userId).get();
      
      if (!userDoc.exists) {
        return null;
      }

      return {
        userId: userDoc.id,
        ...userDoc.data(),
      } as User;
    } catch (error) {
      console.error('Error fetching user:', error);
      throw new Error(`Failed to fetch user: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async getUserByFirebaseUid(firebaseUid: string): Promise<User | null> {
    try {
      const snapshot = await db.collection(this.collection)
        .where('userId', '==', firebaseUid)
        .limit(1)
        .get();

      if (snapshot.empty) {
        return null;
      }

      const userDoc = snapshot.docs[0];
      return {
        userId: userDoc.id,
        ...userDoc.data(),
      } as User;
    } catch (error) {
      console.error('Error fetching user by Firebase UID:', error);
      throw new Error(`Failed to fetch user: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async getUserByEmail(email: string): Promise<User | null> {
    try {
      const snapshot = await db.collection(this.collection)
        .where('email', '==', email)
        .limit(1)
        .get();

      if (snapshot.empty) {
        return null;
      }

      const userDoc = snapshot.docs[0];
      return {
        userId: userDoc.id,
        ...userDoc.data(),
      } as User;
    } catch (error) {
      console.error('Error fetching user by email:', error);
      throw new Error(`Failed to fetch user: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async updateUser(userId: string, data: UserUpdateInput): Promise<User> {
    try {
      const userRef = db.collection(this.collection).doc(userId);
      
      const updateData: Partial<User> = {
        ...data,
        updatedAt: new Date(),
      };

      await userRef.update(updateData);
      
      const updatedUser = await this.getUserById(userId);
      if (!updatedUser) {
        throw new Error('User not found after update');
      }
      
      return updatedUser;
    } catch (error) {
      console.error('Error updating user:', error);
      throw new Error(`Failed to update user: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async updateLastLogin(userId: string): Promise<void> {
    try {
      await db.collection(this.collection).doc(userId).update({
        lastLoginAt: new Date(),
        updatedAt: new Date(),
      });
    } catch (error) {
      console.error('Error updating last login:', error);
      // Don't throw error for login updates - it's not critical
    }
  }

  async deactivateUser(userId: string): Promise<{ success: boolean; message: string }> {
    try {
      const userRef = db.collection(this.collection).doc(userId);
      const userDoc = await userRef.get();

      if (!userDoc.exists) {
        return {
          success: false,
          message: 'User not found',
        };
      }

      await userRef.update({
        isActive: false,
        updatedAt: new Date(),
      });

      return {
        success: true,
        message: `User ${userId} deactivated successfully`,
      };
    } catch (error) {
      console.error('Error deactivating user:', error);
      throw new Error(`Failed to deactivate user: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async activateUser(userId: string): Promise<{ success: boolean; message: string }> {
    try {
      const userRef = db.collection(this.collection).doc(userId);
      const userDoc = await userRef.get();

      if (!userDoc.exists) {
        return {
          success: false,
          message: 'User not found',
        };
      }

      await userRef.update({
        isActive: true,
        updatedAt: new Date(),
      });

      return {
        success: true,
        message: `User ${userId} activated successfully`,
      };
    } catch (error) {
      console.error('Error activating user:', error);
      throw new Error(`Failed to activate user: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async getAllUsers(limit: number = 50): Promise<User[]> {
    try {
      const snapshot = await db.collection(this.collection)
        .orderBy('createdAt', 'desc')
        .limit(limit)
        .get();

      return snapshot.docs.map(doc => ({
        userId: doc.id,
        ...doc.data(),
      })) as User[];
    } catch (error) {
      console.error('Error fetching all users:', error);
      throw new Error(`Failed to fetch users: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async getActiveUsers(): Promise<User[]> {
    try {
      const snapshot = await db.collection(this.collection)
        .where('isActive', '==', true)
        .orderBy('lastLoginAt', 'desc')
        .get();

      return snapshot.docs.map(doc => ({
        userId: doc.id,
        ...doc.data(),
      })) as User[];
    } catch (error) {
      console.error('Error fetching active users:', error);
      throw new Error(`Failed to fetch active users: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async getUserStatistics(): Promise<{
    totalUsers: number;
    activeUsers: number;
    newUsersThisMonth: number;
    usersByEmployer: Array<{ employer: string; count: number }>;
  }> {
    try {
      const now = new Date();
      const firstDayOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

      const snapshot = await db.collection(this.collection).get();
      const allUsers = snapshot.docs.map(doc => doc.data() as User);

      const activeUsers = allUsers.filter(user => user.isActive);
      const newUsersThisMonth = allUsers.filter(user => 
        new Date(user.createdAt) >= firstDayOfMonth
      );

      // Count users by employer
      const employerCounts: { [key: string]: number } = {};
      allUsers.forEach(user => {
        const employer = user.currentEmployer || 'Not Specified';
        employerCounts[employer] = (employerCounts[employer] || 0) + 1;
      });

      const usersByEmployer = Object.entries(employerCounts)
        .map(([employer, count]) => ({ employer, count }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 10);

      return {
        totalUsers: allUsers.length,
        activeUsers: activeUsers.length,
        newUsersThisMonth: newUsersThisMonth.length,
        usersByEmployer,
      };
    } catch (error) {
      console.error('Error getting user statistics:', error);
      throw new Error(`Failed to get user statistics: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async deleteUser(userId: string): Promise<{ success: boolean; message: string }> {
    try {
      const userRef = db.collection(this.collection).doc(userId);
      const userDoc = await userRef.get();

      if (!userDoc.exists) {
        return {
          success: false,
          message: 'User not found',
        };
      }

      await userRef.delete();

      return {
        success: true,
        message: `User ${userId} deleted successfully`,
      };
    } catch (error) {
      console.error('Error deleting user:', error);
      throw new Error(`Failed to delete user: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async searchUsers(query: string, limit: number = 20): Promise<User[]> {
    try {
      const snapshot = await db.collection(this.collection)
        .where('displayName', '>=', query)
        .where('displayName', '<=', query + '\uf8ff')
        .limit(limit)
        .get();

      return snapshot.docs.map(doc => ({
        userId: doc.id,
        ...doc.data(),
      })) as User[];
    } catch (error) {
      console.error('Error searching users:', error);
      throw new Error(`Failed to search users: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
}