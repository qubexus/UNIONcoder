import { db } from '../config/firebase';
import { Case, CaseCreateInput, CaseUpdateInput } from '../types';

export class CaseService {
  private readonly collection = 'cases';

  async createCase(data: CaseCreateInput, agentId: string): Promise<Case> {
    try {
      const caseData: Omit<Case, 'caseId'> = {
        title: data.title,
        description: data.description,
        status: data.status,
        assignedAgentId: agentId,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      const docRef = await db.collection(this.collection).add(caseData);
      
      return {
        caseId: docRef.id,
        ...caseData,
      };
    } catch (error) {
      console.error('Error creating case:', error);
      throw new Error(`Failed to create case: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async getCaseById(caseId: string): Promise<Case | null> {
    try {
      const caseDoc = await db.collection(this.collection).doc(caseId).get();
      
      if (!caseDoc.exists) {
        return null;
      }

      return {
        caseId: caseDoc.id,
        ...caseDoc.data(),
      } as Case;
    } catch (error) {
      console.error('Error fetching case:', error);
      throw new Error(`Failed to fetch case: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async getCasesByAgent(agentId: string): Promise<Case[]> {
    try {
      const snapshot = await db.collection(this.collection)
        .where('assignedAgentId', '==', agentId)
        .orderBy('createdAt', 'desc')
        .get();
      
      return snapshot.docs.map(doc => ({
        caseId: doc.id,
        ...doc.data(),
      })) as Case[];
    } catch (error) {
      console.error('Error fetching agent cases:', error);
      throw new Error(`Failed to fetch agent cases: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async getAllCases(): Promise<Case[]> {
    try {
      const snapshot = await db.collection(this.collection)
        .orderBy('createdAt', 'desc')
        .get();
      
      return snapshot.docs.map(doc => ({
        caseId: doc.id,
        ...doc.data(),
      })) as Case[];
    } catch (error) {
      console.error('Error fetching all cases:', error);
      throw new Error(`Failed to fetch all cases: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async updateCase(caseId: string, data: CaseUpdateInput): Promise<Case> {
    try {
      const caseRef = db.collection(this.collection).doc(caseId);
      
      const updateData: Partial<Case> = {
        ...data,
        updatedAt: new Date(),
      };

      await caseRef.update(updateData);
      
      const updatedCase = await this.getCaseById(caseId);
      if (!updatedCase) {
        throw new Error('Case not found after update');
      }
      
      return updatedCase;
    } catch (error) {
      console.error('Error updating case:', error);
      throw new Error(`Failed to update case: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async deleteCase(caseId: string): Promise<{ success: boolean; message: string }> {
    try {
      const caseRef = db.collection(this.collection).doc(caseId);
      const caseDoc = await caseRef.get();

      if (!caseDoc.exists) {
        return {
          success: false,
          message: 'Case not found',
        };
      }

      await caseRef.delete();

      return {
        success: true,
        message: `Case ${caseId} deleted successfully`,
      };
    } catch (error) {
      console.error('Error deleting case:', error);
      throw new Error(`Failed to delete case: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async getCasesByStatus(status: Case['status']): Promise<Case[]> {
    try {
      const snapshot = await db.collection(this.collection)
        .where('status', '==', status)
        .orderBy('createdAt', 'desc')
        .get();
      
      return snapshot.docs.map(doc => ({
        caseId: doc.id,
        ...doc.data(),
      })) as Case[];
    } catch (error) {
      console.error('Error fetching cases by status:', error);
      throw new Error(`Failed to fetch cases by status: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
}