import { db } from '../config/firebase';
import { License, LicenseUpdateRequest } from '../types';
import { LicenseUpdateInput } from '../validation/schemas';

export class LicenseService {
  private readonly collection = 'licenses';

  async updateLicenseAssignment(data: LicenseUpdateInput): Promise<{ success: boolean; message: string; remainingChanges?: number }> {
    const { licenseId, newUserId, newJobTitle, newCompanyId } = data;

    try {
      const result = await db.runTransaction(async (transaction) => {
        const licenseRef = db.collection(this.collection).doc(licenseId);
        const licenseDoc = await transaction.get(licenseRef);

        if (!licenseDoc.exists) {
          throw new Error('License not found');
        }

        const currentLicense = licenseDoc.data() as License;
        
        // Check if any values actually changed
        const hasUserIdChange = newUserId && newUserId !== currentLicense.assignedUserId;
        const hasJobTitleChange = newJobTitle && newJobTitle !== currentLicense.jobTitle;
        const hasCompanyIdChange = newCompanyId && newCompanyId !== currentLicense.companyId;
        
        const hasAnyChange = hasUserIdChange || hasJobTitleChange || hasCompanyIdChange;

        if (!hasAnyChange) {
          return {
            success: true,
            message: 'No changes detected. License remains unchanged.',
            remainingChanges: currentLicense.changeCounter,
          };
        }

        if (currentLicense.changeCounter <= 0) {
          return {
            success: false,
            message: 'License change limit (3) exhausted. Contact administrator: admin@ai-coder.uk',
            remainingChanges: 0,
          };
        }

        // Decrement counter and update fields
        const updatedData: Partial<License> = {
          changeCounter: currentLicense.changeCounter - 1,
          lastModifiedAt: new Date(),
        };

        if (hasUserIdChange) {
          updatedData.assignedUserId = newUserId!;
        }
        if (hasJobTitleChange) {
          updatedData.jobTitle = newJobTitle!;
        }
        if (hasCompanyIdChange) {
          updatedData.companyId = newCompanyId!;
        }

        transaction.update(licenseRef, updatedData);

        return {
          success: true,
          message: `Assignment updated. Changes remaining: ${currentLicense.changeCounter - 1}`,
          remainingChanges: currentLicense.changeCounter - 1,
        };
      });

      return result;
    } catch (error) {
      console.error('Error in license update transaction:', error);
      throw new Error(`License update failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async getLicenseById(licenseId: string): Promise<License | null> {
    try {
      const licenseDoc = await db.collection(this.collection).doc(licenseId).get();
      
      if (!licenseDoc.exists) {
        return null;
      }

      return {
        licenseId: licenseDoc.id,
        ...licenseDoc.data(),
      } as License;
    } catch (error) {
      console.error('Error fetching license:', error);
      throw new Error(`Failed to fetch license: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async getAllLicenses(): Promise<License[]> {
    try {
      const snapshot = await db.collection(this.collection).get();
      return snapshot.docs.map(doc => ({
        licenseId: doc.id,
        ...doc.data(),
      })) as License[];
    } catch (error) {
      console.error('Error fetching all licenses:', error);
      throw new Error(`Failed to fetch licenses: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async resetLicenseCounter(licenseId: string): Promise<{ success: boolean; message: string }> {
    try {
      const licenseRef = db.collection(this.collection).doc(licenseId);
      const licenseDoc = await licenseRef.get();

      if (!licenseDoc.exists) {
        return {
          success: false,
          message: 'License not found',
        };
      }

      await licenseRef.update({
        changeCounter: 3,
        lastModifiedAt: new Date(),
      });

      return {
        success: true,
        message: `License ${licenseId} counter reset to 3`,
      };
    } catch (error) {
      console.error('Error resetting license counter:', error);
      throw new Error(`Failed to reset license counter: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
}