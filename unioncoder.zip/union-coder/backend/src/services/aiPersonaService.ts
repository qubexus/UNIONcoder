import { db } from '../config/firebase';
import { AIPersona, AIPersonaCreateInput, AIPersonaUpdateInput } from '../types';

export class AIPersonaService {
  private readonly collection = 'ai_personas';

  async createPersona(data: AIPersonaCreateInput, createdBy: string): Promise<AIPersona> {
    try {
      const newPersona: Omit<AIPersona, 'personaId'> = {
        name: data.name,
        title: data.title,
        specialization: data.specialization,
        description: data.description,
        avatar: data.avatar,
        systemPrompt: data.systemPrompt,
        isActive: data.isActive ?? true,
        sortOrder: data.sortOrder ?? 0,
        createdBy,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      const docRef = await db.collection(this.collection).add(newPersona);
      
      return {
        personaId: docRef.id,
        ...newPersona,
      };
    } catch (error) {
      console.error('Error creating persona:', error);
      throw new Error(`Failed to create persona: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async getPersonaById(personaId: string): Promise<AIPersona | null> {
    try {
      const personaDoc = await db.collection(this.collection).doc(personaId).get();
      
      if (!personaDoc.exists) {
        return null;
      }

      return {
        personaId: personaDoc.id,
        ...personaDoc.data(),
      } as AIPersona;
    } catch (error) {
      console.error('Error fetching persona:', error);
      throw new Error(`Failed to fetch persona: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async getAllActivePersonas(): Promise<AIPersona[]> {
    try {
      const snapshot = await db.collection(this.collection)
        .where('isActive', '==', true)
        .orderBy('sortOrder', 'asc')
        .orderBy('name', 'asc')
        .get();

      return snapshot.docs.map(doc => ({
        personaId: doc.id,
        ...doc.data(),
      })) as AIPersona[];
    } catch (error) {
      console.error('Error fetching active personas:', error);
      throw new Error(`Failed to fetch active personas: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async getAllPersonas(): Promise<AIPersona[]> {
    try {
      const snapshot = await db.collection(this.collection)
        .orderBy('sortOrder', 'asc')
        .orderBy('name', 'asc')
        .get();

      return snapshot.docs.map(doc => ({
        personaId: doc.id,
        ...doc.data(),
      })) as AIPersona[];
    } catch (error) {
      console.error('Error fetching all personas:', error);
      throw new Error(`Failed to fetch all personas: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async updatePersona(personaId: string, data: AIPersonaUpdateInput): Promise<AIPersona> {
    try {
      const personaRef = db.collection(this.collection).doc(personaId);
      
      const updateData: Partial<AIPersona> = {
        ...data,
        updatedAt: new Date(),
      };

      await personaRef.update(updateData);
      
      const updatedPersona = await this.getPersonaById(personaId);
      if (!updatedPersona) {
        throw new Error('Persona not found after update');
      }
      
      return updatedPersona;
    } catch (error) {
      console.error('Error updating persona:', error);
      throw new Error(`Failed to update persona: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async deactivatePersona(personaId: string): Promise<{ success: boolean; message: string }> {
    try {
      const personaRef = db.collection(this.collection).doc(personaId);
      const personaDoc = await personaRef.get();

      if (!personaDoc.exists) {
        return {
          success: false,
          message: 'Persona not found',
        };
      }

      await personaRef.update({
        isActive: false,
        updatedAt: new Date(),
      });

      return {
        success: true,
        message: `Persona ${personaId} deactivated successfully`,
      };
    } catch (error) {
      console.error('Error deactivating persona:', error);
      throw new Error(`Failed to deactivate persona: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async activatePersona(personaId: string): Promise<{ success: boolean; message: string }> {
    try {
      const personaRef = db.collection(this.collection).doc(personaId);
      const personaDoc = await personaRef.get();

      if (!personaDoc.exists) {
        return {
          success: false,
          message: 'Persona not found',
        };
      }

      await personaRef.update({
        isActive: true,
        updatedAt: new Date(),
      });

      return {
        success: true,
        message: `Persona ${personaId} activated successfully`,
      };
    } catch (error) {
      console.error('Error activating persona:', error);
      throw new Error(`Failed to activate persona: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async deletePersona(personaId: string): Promise<{ success: boolean; message: string }> {
    try {
      const personaRef = db.collection(this.collection).doc(personaId);
      const personaDoc = await personaRef.get();

      if (!personaDoc.exists) {
        return {
          success: false,
          message: 'Persona not found',
        };
      }

      await personaRef.delete();

      return {
        success: true,
        message: `Persona ${personaId} deleted successfully`,
      };
    } catch (error) {
      console.error('Error deleting persona:', error);
      throw new Error(`Failed to delete persona: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async getPersonaStatistics(): Promise<{
    totalPersonas: number;
    activePersonas: number;
    personasBySpecialization: Array<{ specialization: string; count: number }>;
  }> {
    try {
      const snapshot = await db.collection(this.collection).get();
      const allPersonas = snapshot.docs.map(doc => doc.data() as AIPersona);

      const activePersonas = allPersonas.filter(persona => persona.isActive);

      // Count personas by specialization
      const specializationCounts: { [key: string]: number } = {};
      allPersonas.forEach(persona => {
        const specialization = persona.specialization;
        specializationCounts[specialization] = (specializationCounts[specialization] || 0) + 1;
      });

      const personasBySpecialization = Object.entries(specializationCounts)
        .map(([specialization, count]) => ({ specialization, count }))
        .sort((a, b) => b.count - a.count);

      return {
        totalPersonas: allPersonas.length,
        activePersonas: activePersonas.length,
        personasBySpecialization,
      };
    } catch (error) {
      console.error('Error getting persona statistics:', error);
      throw new Error(`Failed to get persona statistics: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async searchPersonas(query: string, limit: number = 20): Promise<AIPersona[]> {
    try {
      const snapshot = await db.collection(this.collection)
        .where('name', '>=', query)
        .where('name', '<=', query + '\uf8ff')
        .limit(limit)
        .get();

      return snapshot.docs.map(doc => ({
        personaId: doc.id,
        ...doc.data(),
      })) as AIPersona[];
    } catch (error) {
      console.error('Error searching personas:', error);
      throw new Error(`Failed to search personas: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async reorderPersonas(personaIds: string[]): Promise<{ success: boolean; message: string }> {
    try {
      const batch = db.batch();
      
      personaIds.forEach((personaId, index) => {
        const personaRef = db.collection(this.collection).doc(personaId);
        batch.update(personaRef, {
          sortOrder: index,
          updatedAt: new Date(),
        });
      });

      await batch.commit();

      return {
        success: true,
        message: `Personas reordered successfully`,
      };
    } catch (error) {
      console.error('Error reordering personas:', error);
      throw new Error(`Failed to reorder personas: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  // Initialize default personas on first setup
  async initializeDefaultPersonas(): Promise<void> {
    try {
      const existingPersonas = await this.getAllPersonas();
      if (existingPersonas.length > 0) {
        console.log('Default personas already exist, skipping initialization');
        return;
      }

      const defaultPersonas: Array<AIPersonaCreateInput & { createdBy: string }> = [
        {
          name: 'Sarah Martinez',
          title: 'Contract Specialist',
          specialization: 'Employment Contracts',
          description: 'Expert in employment contract review, negotiation, and dispute resolution',
          avatar: '📋',
          systemPrompt: 'You are Sarah Martinez, a Contract Specialist at UNIONcoder. You are an expert in employment contracts, workplace agreements, and labor law. Your role is to help employees understand their contract rights, identify potential violations, and guide them through contract disputes. Always be thorough, professional, and focused on protecting employee rights. Explain complex legal concepts in simple terms and provide actionable advice.',
          isActive: true,
          sortOrder: 0,
          createdBy: 'system',
        },
        {
          name: 'David Chen',
          title: 'Harassment Expert',
          specialization: 'Workplace Harassment',
          description: 'Specialized in handling workplace harassment, discrimination, and hostile work environment cases',
          avatar: '🛡️',
          systemPrompt: 'You are David Chen, a Harassment Expert at UNIONcoder. You specialize in workplace harassment, discrimination, bullying, and creating safe work environments. Your role is to provide compassionate support while helping employees understand their rights and options. Always prioritize the employee\'s safety and well-being. Be empathetic but professional, and provide clear guidance on reporting procedures and legal protections.',
          isActive: true,
          sortOrder: 1,
          createdBy: 'system',
        },
        {
          name: 'Maria Rodriguez',
          title: 'Wage & Benefits Advisor',
          specialization: 'Compensation & Benefits',
          description: 'Expert in wage disputes, overtime pay, benefits, and compensation negotiations',
          avatar: '💰',
          systemPrompt: 'You are Maria Rodriguez, a Wage & Benefits Advisor at UNIONcoder. You are an expert in employment compensation, wage laws, overtime rules, and employee benefits. Your role is to help employees understand their compensation rights, identify wage violations, and navigate benefits issues. Be detail-oriented and practical, focusing on helping employees recover what they are owed under the law.',
          isActive: true,
          sortOrder: 2,
          createdBy: 'system',
        },
        {
          name: 'James Thompson',
          title: 'Termination Rights Specialist',
          specialization: 'Wrongful Termination',
          description: 'Focused on termination rights, severance negotiations, and wrongful termination claims',
          avatar: '⚖️',
          systemPrompt: 'You are James Thompson, a Termination Rights Specialist at UNIONcoder. You specialize in wrongful termination, severance negotiations, and employee rights during job transitions. Your role is to help employees understand their termination rights, evaluate whether their termination was lawful, and guide them through next steps. Be direct and practical while being sensitive to the stressful nature of job loss.',
          isActive: true,
          sortOrder: 3,
          createdBy: 'system',
        },
        {
          name: 'Lisa Park',
          title: 'Workplace Safety Advocate',
          specialization: 'OSHA & Safety Regulations',
          description: 'Expert in workplace safety, OSHA regulations, and hazardous working conditions',
          avatar: '🦺',
          systemPrompt: 'You are Lisa Park, a Workplace Safety Advocate at UNIONcoder. You specialize in workplace safety regulations, OSHA compliance, and hazardous working conditions. Your role is to help employees understand their safety rights and take action when workplaces are unsafe. Be proactive and thorough in identifying safety violations and guide employees through proper reporting channels.',
          isActive: true,
          sortOrder: 4,
          createdBy: 'system',
        },
      ];

      for (const personaData of defaultPersonas) {
        await this.createPersona(personaData, personaData.createdBy);
      }

      console.log('Default AI personas initialized successfully');
    } catch (error) {
      console.error('Error initializing default personas:', error);
      throw new Error(`Failed to initialize default personas: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
}