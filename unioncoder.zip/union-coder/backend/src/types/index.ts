// UPDATED UNIONcoder Types - PIVOTED VERSION
// Removed license-focused types, added AI chat functionality

export interface User {
  userId: string;
  email: string;
  displayName: string;
  currentEmployer?: string;
  department?: string;
  jobTitle?: string;
  joinDate: Date;
  lastLoginAt: Date;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface AIPersona {
  personaId: string;
  name: string;
  title: string;
  specialization: string;
  description: string;
  avatar: string; // URL or emoji
  systemPrompt: string; // AI system prompt for this persona
  isActive: boolean;
  sortOrder: number;
  createdBy: string; // Admin ID
  createdAt: Date;
  updatedAt: Date;
}

export interface Conversation {
  conversationId: string;
  userId: string; // Employee user ID
  personaId: string; // AI persona ID
  title: string; // Auto-generated from first message
  status: 'active' | 'archived' | 'flagged';
  messages: Message[];
  startedAt: Date;
  lastMessageAt: Date;
  isResolved: boolean;
  category?: string; // Auto-categorized
  tags: string[];
}

export interface Message {
  messageId: string;
  sender: 'user' | 'ai';
  content: string;
  timestamp: Date;
  metadata?: {
    processingTime?: number;
    aiModel?: string;
    tokensUsed?: number;
    confidence?: number;
  };
}

export interface CreateConversationRequest {
  personaId: string;
  initialMessage: string;
}

export interface SendMessageRequest {
  conversationId: string;
  content: string;
}

export interface ChatResponse {
  conversationId: string;
  message: Message;
  suggestions?: string[]; // AI-generated follow-up questions
  category?: string; // Auto-category assignment
}

export interface AIPersonaCreate {
  name: string;
  title: string;
  specialization: string;
  description: string;
  avatar: string;
  systemPrompt: string;
  isActive?: boolean;
  sortOrder?: number;
}

export interface AIPersonaUpdate {
  name?: string;
  title?: string;
  specialization?: string;
  description?: string;
  avatar?: string;
  systemPrompt?: string;
  isActive?: boolean;
  sortOrder?: number;
}

// Admin types
export interface UserManagement {
  users: User[];
  totalUsers: number;
  activeUsers: number;
  newUsersThisMonth: number;
}

export interface ConversationAnalytics {
  totalConversations: number;
  activeConversations: number;
  resolvedConversations: number;
  averageMessagesPerConversation: number;
  popularPersonas: Array<{
    personaId: string;
    personaName: string;
    usageCount: number;
  }>;
}

export interface SystemHealth {
  status: 'healthy' | 'degraded' | 'down';
  aiService: 'operational' | 'degraded' | 'down';
  database: 'operational' | 'degraded' | 'down';
  activeConnections: number;
  uptime: number;
  lastRestart: Date;
}