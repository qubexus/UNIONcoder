import { ChatService } from '../src/services/chatService';
import { AIPersonaService } from '../src/services/aiPersonaService';

// Mock Firebase
jest.mock('../src/config/firebase', () => ({
  db: {
    collection: jest.fn(() => ({
      doc: jest.fn(() => ({
        get: jest.fn(),
        set: jest.fn(),
        update: jest.fn(),
        delete: jest.fn(),
      })),
      add: jest.fn(),
      where: jest.fn(() => ({
        limit: jest.fn(() => ({
          get: jest.fn(),
        })),
      })),
      orderBy: jest.fn(() => ({
        limit: jest.fn(() => ({
          get: jest.fn(),
        })),
      })),
    })),
    runTransaction: jest.fn(),
  },
}));

describe('ChatService', () => {
  let chatService: ChatService;
  let aiPersonaService: AIPersonaService;

  beforeEach(() => {
    chatService = new ChatService();
    aiPersonaService = new AIPersonaService();
  });

  describe('createConversation', () => {
    it('should create a new conversation with AI response', async () => {
      const userId = 'test-user-123';
      const personaId = 'test-persona-456';
      const initialMessage = 'I need help with my contract';

      // Mock persona data
      const mockPersona = {
        personaId,
        name: 'Sarah Martinez',
        title: 'Contract Specialist',
        specialization: 'Employment Contracts',
        systemPrompt: 'You are a contract specialist...',
        isActive: true,
      };

      // Mock the persona service
      jest.spyOn(aiPersonaService, 'getPersonaById').mockResolvedValue(mockPersona as any);

      // Test the conversation creation
      const result = await chatService.createConversation(userId, {
        personaId,
        initialMessage,
      });

      expect(result).toBeDefined();
      expect(result.userId).toBe(userId);
      expect(result.personaId).toBe(personaId);
      expect(result.messages).toHaveLength(2); // User message + AI response
      expect(result.messages[0].sender).toBe('user');
      expect(result.messages[1].sender).toBe('ai');
    });

    it('should throw error if persona is not found', async () => {
      const userId = 'test-user-123';
      const personaId = 'non-existent-persona';
      const initialMessage = 'Test message';

      // Mock persona not found
      jest.spyOn(aiPersonaService, 'getPersonaById').mockResolvedValue(null);

      await expect(chatService.createConversation(userId, {
        personaId,
        initialMessage,
      })).rejects.toThrow('Persona not found or inactive');
    });

    it('should throw error if persona is inactive', async () => {
      const userId = 'test-user-123';
      const personaId = 'inactive-persona';
      const initialMessage = 'Test message';

      // Mock inactive persona
      const mockPersona = {
        personaId,
        isActive: false,
      };

      jest.spyOn(aiPersonaService, 'getPersonaById').mockResolvedValue(mockPersona as any);

      await expect(chatService.createConversation(userId, {
        personaId,
        initialMessage,
      })).rejects.toThrow('Persona not found or inactive');
    });
  });

  describe('sendMessage', () => {
    it('should send message and get AI response', async () => {
      const userId = 'test-user-123';
      const conversationId = 'test-conversation-789';
      const messageContent = 'I have another question';

      // Mock existing conversation
      const mockConversation = {
        conversationId,
        userId,
        personaId: 'test-persona-456',
        messages: [
          {
            messageId: 'msg-1',
            sender: 'user' as const,
            content: 'Initial message',
            timestamp: new Date(),
          },
        ],
      };

      // Mock persona
      const mockPersona = {
        personaId: 'test-persona-456',
        name: 'Sarah Martinez',
        systemPrompt: 'You are a contract specialist...',
      };

      // Test sending message
      const result = await chatService.sendMessage(userId, {
        conversationId,
        content: messageContent,
      });

      expect(result).toBeDefined();
      expect(result.conversationId).toBe(conversationId);
      expect(result.message.sender).toBe('ai');
      expect(result.message.content).toBeDefined();
    });

    it('should throw error if conversation is not found', async () => {
      const userId = 'test-user-123';
      const conversationId = 'non-existent-conversation';
      const messageContent = 'Test message';

      await expect(chatService.sendMessage(userId, {
        conversationId,
        content: messageContent,
      })).rejects.toThrow('Conversation not found');
    });

    it('should throw error if user does not own the conversation', async () => {
      const userId = 'test-user-123';
      const conversationId = 'other-users-conversation';
      const messageContent = 'Test message';

      // Mock conversation owned by another user
      const mockConversation = {
        conversationId,
        userId: 'other-user-456', // Different user
        personaId: 'test-persona-456',
        messages: [],
      };

      await expect(chatService.sendMessage(userId, {
        conversationId,
        content: messageContent,
      })).rejects.toThrow('Access denied: You can only send messages to your own conversations');
    });
  });

  describe('getConversations', () => {
    it('should return user conversations', async () => {
      const userId = 'test-user-123';
      const limit = 20;

      const result = await chatService.getConversations(userId, limit);

      expect(Array.isArray(result)).toBe(true);
      // Each conversation should have the expected structure
      result.forEach(conversation => {
        expect(conversation).toHaveProperty('conversationId');
        expect(conversation).toHaveProperty('userId');
        expect(conversation).toHaveProperty('messages');
        expect(conversation).toHaveProperty('startedAt');
        expect(conversation).toHaveProperty('lastMessageAt');
      });
    });

    it('should respect the limit parameter', async () => {
      const userId = 'test-user-123';
      const limit = 5;

      const result = await chatService.getConversations(userId, limit);

      expect(result.length).toBeLessThanOrEqual(limit);
    });
  });

  describe('deleteConversation', () => {
    it('should delete user conversation', async () => {
      const userId = 'test-user-123';
      const conversationId = 'test-conversation-789';

      const result = await chatService.deleteConversation(userId, conversationId);

      expect(result.success).toBeDefined();
      if (result.success) {
        expect(result.message).toContain('deleted successfully');
      }
    });

    it('should return error if conversation is not found', async () => {
      const userId = 'test-user-123';
      const conversationId = 'non-existent-conversation';

      const result = await chatService.deleteConversation(userId, conversationId);

      expect(result.success).toBe(false);
      expect(result.message).toContain('not found');
    });
  });
});