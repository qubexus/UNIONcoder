// Jest setup file for UNIONcoder backend tests

// Mock console methods to reduce noise in tests
global.console = {
  ...console,
  log: jest.fn(),
  debug: jest.fn(),
  info: jest.fn(),
  warn: jest.fn(),
  error: jest.fn(),
};

// Mock Firebase Admin SDK
jest.mock('firebase-admin', () => ({
  initializeApp: jest.fn(),
  apps: [],
  credential: {
    cert: jest.fn(),
  },
  firestore: () => ({
    collection: jest.fn(() => ({
      doc: jest.fn(() => ({
        get: jest.fn(),
        set: jest.fn(),
        update: jest.fn(),
        delete: jest.fn(),
      })),
      add: jest.fn(),
      where: jest.fn(() => ({
        limit: jest.fn(() => ({
          get: jest.fn(),
          orderBy: jest.fn(() => ({
            get: jest.fn(),
          })),
        })),
      })),
      orderBy: jest.fn(() => ({
        limit: jest.fn(() => ({
          get: jest.fn(),
        })),
      })),
    })),
    runTransaction: jest.fn(),
    batch: jest.fn(),
    Timestamp: {
      fromDate: (date: Date) => ({ toDate: () => date }),
    },
    FieldValue: {
      serverTimestamp: () => 'mock-timestamp',
    },
  }),
  auth: () => ({
    verifyIdToken: jest.fn(),
    createUser: jest.fn(),
    updateUser: jest.fn(),
    deleteUser: jest.fn(),
  }),
}));

// Global test helpers
global.createMockUser = () => ({
  userId: 'test-user-123',
  email: 'test@example.com',
  displayName: 'Test User',
  currentEmployer: 'Test Company',
  department: 'IT',
  jobTitle: 'Developer',
  isActive: true,
  createdAt: new Date('2024-01-01'),
  lastLoginAt: new Date(),
});

global.createMockPersona = () => ({
  personaId: 'test-persona-456',
  name: 'Test AI Agent',
  title: 'Test Specialist',
  specialization: 'Test Area',
  description: 'Test AI persona for testing',
  avatar: '🤖',
  systemPrompt: 'You are a test AI persona...',
  isActive: true,
  sortOrder: 0,
  createdBy: 'admin-user',
  createdAt: new Date('2024-01-01'),
  updatedAt: new Date(),
});

global.createMockConversation = () => ({
  conversationId: 'test-conversation-789',
  userId: 'test-user-123',
  personaId: 'test-persona-456',
  title: 'Test Conversation',
  status: 'active' as const,
  messages: [
    {
      messageId: 'msg-1',
      sender: 'user' as const,
      content: 'Hello, I need help with something',
      timestamp: new Date(),
    },
    {
      messageId: 'msg-2',
      sender: 'ai' as const,
      content: 'Hello! I\'m here to help you with your workplace issues.',
      timestamp: new Date(),
      metadata: {
        processingTime: 1500,
        aiModel: 'claude-3-sonnet',
        tokensUsed: 45,
      },
    },
  ],
  startedAt: new Date('2024-01-01'),
  lastMessageAt: new Date(),
  isResolved: false,
  category: 'General Inquiry',
  tags: ['test', 'help'],
});

// Mock environment variables
process.env.NODE_ENV = 'test';
process.env.FIREBASE_PROJECT_ID = 'test-project';
process.env.FIREBASE_PRIVATE_KEY = 'test-key';
process.env.FIREBASE_CLIENT_EMAIL = 'test@test.com';
process.env.PORT = '3001';
process.env.JWT_SECRET = 'test-jwt-secret';