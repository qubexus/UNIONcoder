import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Alert,
  TextInput,
  Modal,
  StyleSheet,
} from 'react-native';
import { useChat } from '../contexts/ChatContext';
import { useAuth } from '../contexts/AuthContext';

interface AIPersona {
  personaId: string;
  name: string;
  title: string;
  specialization: string;
  description: string;
  avatar: string;
  isActive: boolean;
  sortOrder: number;
}

const PersonaSelectionScreen: React.FC = () => {
  const { personas, loading, createConversation } = useChat();
  const { user } = useAuth();
  const [selectedPersona, setSelectedPersona] = useState<AIPersona | null>(null);
  const [initialMessage, setInitialMessage] = useState('');
  const [showChatModal, setShowChatModal] = useState(false);

  useEffect(() => {
    // Personas are loaded automatically by ChatProvider
  }, []);

  const handlePersonaSelect = (persona: AIPersona) => {
    setSelectedPersona(persona);
    setShowChatModal(true);
  };

  const handleStartChat = async () => {
    if (!selectedPersona || !initialMessage.trim()) {
      Alert.alert('Error', 'Please enter a message to start the conversation.');
      return;
    }

    try {
      await createConversation(selectedPersona.personaId, initialMessage.trim());
      setShowChatModal(false);
      setSelectedPersona(null);
      setInitialMessage('');
      
      // Navigate to chat tab (this would typically be handled by navigation)
      Alert.alert('Success', 'Conversation started! Check the Chat tab.');
    } catch (error) {
      Alert.alert('Error', 'Failed to start conversation. Please try again.');
    }
  };

  const renderPersonaCard = (persona: AIPersona) => (
    <TouchableOpacity
      key={persona.personaId}
      style={styles.personaCard}
      onPress={() => handlePersonaSelect(persona)}
      activeOpacity={0.7}
    >
      <View style={styles.personaHeader}>
        <Text style={styles.personaAvatar}>{persona.avatar}</Text>
        <View style={styles.personaInfo}>
          <Text style={styles.personaName}>{persona.name}</Text>
          <Text style={styles.personaTitle}>{persona.title}</Text>
        </View>
      </View>
      
      <View style={styles.specializationBadge}>
        <Text style={styles.specializationText}>{persona.specialization}</Text>
      </View>
      
      <Text style={styles.personaDescription}>{persona.description}</Text>
      
      <TouchableOpacity style={styles.chatButton}>
        <Text style={styles.chatButtonText}>Start Chat</Text>
      </TouchableOpacity>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>AI Legal Experts</Text>
        <Text style={styles.headerSubtitle}>
          Choose an AI agent to help with your workplace issues
        </Text>
      </View>

      {/* Personas List */}
      <ScrollView 
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {loading ? (
          <View style={styles.loadingContainer}>
            <Text style={styles.loadingText}>Loading AI agents...</Text>
          </View>
        ) : personas.length > 0 ? (
          personas.map(renderPersonaCard)
        ) : (
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>No AI agents available</Text>
            <Text style={styles.emptySubtext}>
              Please check back later or contact support
            </Text>
          </View>
        )}
      </ScrollView>

      {/* Chat Start Modal */}
      <Modal
        visible={showChatModal}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setShowChatModal(false)}
      >
        <View style={styles.modalContainer}>
          {/* Modal Header */}
          <View style={styles.modalHeader}>
            <TouchableOpacity
              style={styles.cancelButton}
              onPress={() => setShowChatModal(false)}
            >
              <Text style={styles.cancelButtonText}>Cancel</Text>
            </TouchableOpacity>
            <Text style={styles.modalTitle}>Start Conversation</Text>
            <View style={styles.placeholder} />
          </View>

          {/* Selected Persona Info */}
          {selectedPersona && (
            <View style={styles.selectedPersona}>
              <View style={styles.selectedPersonaHeader}>
                <Text style={styles.selectedPersonaAvatar}>{selectedPersona.avatar}</Text>
                <View style={styles.selectedPersonaInfo}>
                  <Text style={styles.selectedPersonaName}>{selectedPersona.name}</Text>
                  <Text style={styles.selectedPersonaTitle}>{selectedPersona.title}</Text>
                </View>
              </View>
            </View>
          )}

          {/* Message Input */}
          <View style={styles.messageInputContainer}>
            <Text style={styles.messageLabel}>What would you like help with?</Text>
            <TextInput
              style={styles.messageInput}
              placeholder="Describe your workplace issue..."
              multiline
              numberOfLines={4}
              value={initialMessage}
              onChangeText={setInitialMessage}
              textAlignVertical="top"
            />
          </View>

          {/* Start Chat Button */}
          <TouchableOpacity
            style={[
              styles.startChatButton,
              (!initialMessage.trim() || !selectedPersona) && styles.disabledButton,
            ]}
            onPress={handleStartChat}
            disabled={!initialMessage.trim() || !selectedPersona}
          >
            <Text style={styles.startChatButtonText}>Start Chat</Text>
          </TouchableOpacity>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF', // Primary white
  },
  header: {
    backgroundColor: '#8A2BE2', // Brand purple
    paddingTop: 60,
    paddingHorizontal: 20,
    paddingBottom: 30,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 8,
  },
  headerSubtitle: {
    fontSize: 16,
    color: '#FFFFFF',
    opacity: 0.9,
    lineHeight: 22,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    fontSize: 16,
    color: '#4A5568', // Neutral gray
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 60,
  },
  emptyText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#4A5568',
    marginBottom: 8,
  },
  emptySubtext: {
    fontSize: 14,
    color: '#718096',
    textAlign: 'center',
  },
  personaCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 5,
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  personaHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  personaAvatar: {
    fontSize: 40,
    marginRight: 16,
  },
  personaInfo: {
    flex: 1,
  },
  personaName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#2D3748',
    marginBottom: 4,
  },
  personaTitle: {
    fontSize: 14,
    color: '#8A2BE2', // Brand purple
    fontWeight: '600',
  },
  specializationBadge: {
    backgroundColor: '#FFD700', // Warning yellow
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    alignSelf: 'flex-start',
    marginBottom: 12,
  },
  specializationText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#744210',
  },
  personaDescription: {
    fontSize: 14,
    color: '#4A5568', // Neutral gray
    lineHeight: 20,
    marginBottom: 16,
    flex: 1,
  },
  chatButton: {
    backgroundColor: '#FF8C00', // Accent orange
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  chatButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '600',
  },
  modalContainer: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
  },
  cancelButton: {
    padding: 8,
  },
  cancelButtonText: {
    fontSize: 16,
    color: '#4A5568',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#2D3748',
  },
  placeholder: {
    width: 60,
  },
  selectedPersona: {
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
  },
  selectedPersonaHeader: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  selectedPersonaAvatar: {
    fontSize: 36,
    marginRight: 16,
  },
  selectedPersonaInfo: {
    flex: 1,
  },
  selectedPersonaName: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#2D3748',
    marginBottom: 4,
  },
  selectedPersonaTitle: {
    fontSize: 16,
    color: '#8A2BE2',
    fontWeight: '600',
  },
  messageInputContainer: {
    padding: 20,
    flex: 1,
  },
  messageLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#2D3748',
    marginBottom: 12,
  },
  messageInput: {
    borderWidth: 1,
    borderColor: '#E2E8F0',
    borderRadius: 8,
    padding: 16,
    fontSize: 16,
    color: '#2D3748',
    minHeight: 120,
    maxHeight: 200,
  },
  startChatButton: {
    backgroundColor: '#FF8C00',
    margin: 20,
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  disabledButton: {
    backgroundColor: '#CBD5E0',
  },
  startChatButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
});

export default PersonaSelectionScreen;