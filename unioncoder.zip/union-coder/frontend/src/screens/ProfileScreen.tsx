import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Alert,
  TextInput,
  Switch,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../contexts/AuthContext';

interface User {
  uid: string;
  email: string;
  displayName?: string;
  currentEmployer?: string;
  department?: string;
  jobTitle?: string;
  isActive: boolean;
  createdAt: Date;
  lastLoginAt: Date;
}

const ProfileScreen: React.FC = () => {
  const { user, logout, updateProfile, createProfile } = useAuth();
  
  const [editing, setEditing] = useState(false);
  const [displayName, setDisplayName] = useState('');
  const [currentEmployer, setCurrentEmployer] = useState('');
  const [department, setDepartment] = useState('');
  const [jobTitle, setJobTitle] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (user) {
      setDisplayName(user.displayName || '');
      setCurrentEmployer(user.currentEmployer || '');
      setDepartment(user.department || '');
      setJobTitle(user.jobTitle || '');
    }
  }, [user]);

  const handleSave = async () => {
    if (!user) return;

    setSaving(true);
    try {
      const updateData = {
        displayName: displayName.trim(),
        currentEmployer: currentEmployer.trim(),
        department: department.trim(),
        jobTitle: jobTitle.trim(),
      };

      // Check if user has a profile already
      if (user.displayName) {
        await updateProfile(updateData);
      } else {
        await createProfile(updateData);
      }

      setEditing(false);
      Alert.alert('Success', 'Profile updated successfully');
    } catch (error) {
      Alert.alert('Error', 'Failed to update profile');
    } finally {
      setSaving(false);
    }
  };

  const handleLogout = () => {
    Alert.alert(
      'Logout',
      'Are you sure you want to logout?',
      [
        {
          text: 'Cancel',
          style: 'cancel',
        },
        {
          text: 'Logout',
          style: 'destructive',
          onPress: async () => {
            try {
              await logout();
            } catch (error) {
              Alert.alert('Error', 'Failed to logout');
            }
          },
        },
      ]
    );
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const calculateProfileCompleteness = () => {
    if (!user) return 0;
    
    const fields = [
      user.displayName,
      user.currentEmployer,
      user.department,
      user.jobTitle,
    ];
    
    const completedFields = fields.filter(field => field && field.trim() !== '').length;
    return Math.round((completedFields / fields.length) * 100);
  };

  if (!user) {
    return (
      <View style={styles.loadingContainer}>
        <Text style={styles.loadingText}>Loading profile...</Text>
      </View>
    );
  }

  const profileCompleteness = calculateProfileCompleteness();

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.profileHeader}>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>
              {user.displayName?.charAt(0).toUpperCase() || user.email.charAt(0).toUpperCase()}
            </Text>
          </View>
          <View style={styles.profileInfo}>
            <Text style={styles.name}>
              {user.displayName || 'Set Your Name'}
            </Text>
            <Text style={styles.email}>{user.email}</Text>
            <View style={styles.statusBadge}>
              <Text style={styles.statusText}>Active User</Text>
            </View>
          </View>
        </View>
        
        <View style={styles.completenessContainer}>
          <Text style={styles.completenessLabel}>Profile Completeness</Text>
          <Text style={styles.completenessValue}>{profileCompleteness}%</Text>
        </View>
      </View>

      {/* Profile Form */}
      <View style={styles.formSection}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Personal Information</Text>
          <TouchableOpacity
            style={styles.editButton}
            onPress={() => setEditing(!editing)}
          >
            <Ionicons 
              name={editing ? 'close' : 'create-outline'} 
              size={20} 
              color="#8A2BE2" 
            />
          </TouchableOpacity>
        </View>

        <View style={styles.formGroup}>
          <Text style={styles.label}>Display Name</Text>
          <TextInput
            style={[
              styles.input,
              !editing && styles.inputDisabled,
            ]}
            value={displayName}
            onChangeText={setDisplayName}
            placeholder="Enter your name"
            editable={editing}
          />
        </View>

        <View style={styles.formGroup}>
          <Text style={styles.label}>Current Employer</Text>
          <TextInput
            style={[
              styles.input,
              !editing && styles.inputDisabled,
            ]}
            value={currentEmployer}
            onChangeText={setCurrentEmployer}
            placeholder="Enter your employer"
            editable={editing}
          />
        </View>

        <View style={styles.formGroup}>
          <Text style={styles.label}>Department</Text>
          <TextInput
            style={[
              styles.input,
              !editing && styles.inputDisabled,
            ]}
            value={department}
            onChangeText={setDepartment}
            placeholder="Enter your department"
            editable={editing}
          />
        </View>

        <View style={styles.formGroup}>
          <Text style={styles.label}>Job Title</Text>
          <TextInput
            style={[
              styles.input,
              !editing && styles.inputDisabled,
            ]}
            value={jobTitle}
            onChangeText={setJobTitle}
            placeholder="Enter your job title"
            editable={editing}
          />
        </View>

        {editing && (
          <TouchableOpacity
            style={[styles.saveButton, saving && styles.disabledButton]}
            onPress={handleSave}
            disabled={saving}
          >
            <Text style={styles.saveButtonText}>
              {saving ? 'Saving...' : 'Save Changes'}
            </Text>
          </TouchableOpacity>
        )}
      </View>

      {/* Account Information */}
      <View style={styles.infoSection}>
        <Text style={styles.sectionTitle}>Account Information</Text>
        
        <View style={styles.infoRow}>
          <Text style={styles.infoLabel}>Member Since</Text>
          <Text style={styles.infoValue}>{formatDate(user.createdAt)}</Text>
        </View>
        
        <View style={styles.infoRow}>
          <Text style={styles.infoLabel}>Last Login</Text>
          <Text style={styles.infoValue}>{formatDate(user.lastLoginAt)}</Text>
        </View>
        
        <View style={styles.infoRow}>
          <Text style={styles.infoLabel}>Account Status</Text>
          <View style={styles.statusContainer}>
            <View style={styles.statusDot} />
            <Text style={styles.infoValue}>Active</Text>
          </View>
        </View>
      </View>

      {/* App Settings */}
      <View style={styles.settingsSection}>
        <Text style={styles.sectionTitle}>App Settings</Text>
        
        <View style={styles.settingRow}>
          <View style={styles.settingInfo}>
            <Text style={styles.settingLabel}>Push Notifications</Text>
            <Text style={styles.settingDescription}>
              Receive notifications about your conversations
            </Text>
          </View>
          <Switch value={true} onValueChange={() => {}} />
        </View>
        
        <View style={styles.settingRow}>
          <View style={styles.settingInfo}>
            <Text style={styles.settingLabel}>Email Updates</Text>
            <Text style={styles.settingDescription}>
              Get email summaries of your conversations
            </Text>
          </View>
          <Switch value={false} onValueChange={() => {}} />
        </View>
      </View>

      {/* Support Section */}
      <View style={styles.supportSection}>
        <Text style={styles.sectionTitle}>Support</Text>
        
        <TouchableOpacity style={styles.supportRow}>
          <Ionicons name="help-circle-outline" size={20} color="#8A2BE2" />
          <Text style={styles.supportText}>Help Center</Text>
          <Ionicons name="chevron-forward" size={16} color="#CBD5E0" />
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.supportRow}>
          <Ionicons name="mail-outline" size={20} color="#8A2BE2" />
          <Text style={styles.supportText}>Contact Support</Text>
          <Ionicons name="chevron-forward" size={16} color="#CBD5E0" />
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.supportRow}>
          <Ionicons name="shield-checkmark-outline" size={20} color="#8A2BE2" />
          <Text style={styles.supportText}>Privacy Policy</Text>
          <Ionicons name="chevron-forward" size={16} color="#CBD5E0" />
        </TouchableOpacity>
      </View>

      {/* Logout Button */}
      <View style={styles.logoutSection}>
        <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
          <Ionicons name="log-out-outline" size={20} color="#FFFFFF" />
          <Text style={styles.logoutButtonText}>Logout</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.footer}>
        <Text style={styles.footerText}>UNIONcoder v2.0.0</Text>
        <Text style={styles.footerText}>© 2024 www.ai-coder.uk</Text>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    fontSize: 16,
    color: '#4A5568',
  },
  header: {
    backgroundColor: '#8A2BE2',
    paddingTop: 60,
    paddingHorizontal: 20,
    paddingBottom: 30,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
  },
  profileHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  avatarText: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#8A2BE2',
  },
  profileInfo: {
    flex: 1,
  },
  name: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  email: {
    fontSize: 16,
    color: '#FFFFFF',
    opacity: 0.9,
    marginBottom: 8,
  },
  statusBadge: {
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
    alignSelf: 'flex-start',
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  completenessContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  completenessLabel: {
    fontSize: 14,
    color: '#FFFFFF',
    opacity: 0.9,
  },
  completenessValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  formSection: {
    margin: 20,
    padding: 20,
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#2D3748',
  },
  editButton: {
    padding: 8,
  },
  formGroup: {
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: '#4A5568',
    marginBottom: 8,
  },
  input: {
    borderWidth: 1,
    borderColor: '#E2E8F0',
    borderRadius: 8,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 16,
    color: '#2D3748',
    backgroundColor: '#FFFFFF',
  },
  inputDisabled: {
    backgroundColor: '#F7FAFC',
    color: '#718096',
  },
  saveButton: {
    backgroundColor: '#FF8C00',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 8,
  },
  disabledButton: {
    backgroundColor: '#CBD5E0',
  },
  saveButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  infoSection: {
    margin: 20,
    padding: 20,
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#F7FAFC',
  },
  infoLabel: {
    fontSize: 14,
    color: '#4A5568',
  },
  infoValue: {
    fontSize: 14,
    fontWeight: '600',
    color: '#2D3748',
  },
  statusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#10B981',
    marginRight: 8,
  },
  settingsSection: {
    margin: 20,
    padding: 20,
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  settingRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#F7FAFC',
  },
  settingInfo: {
    flex: 1,
  },
  settingLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#2D3748',
    marginBottom: 4,
  },
  settingDescription: {
    fontSize: 14,
    color: '#718096',
  },
  supportSection: {
    margin: 20,
    padding: 20,
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  supportRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#F7FAFC',
  },
  supportText: {
    flex: 1,
    fontSize: 16,
    color: '#2D3748',
    marginLeft: 16,
  },
  logoutSection: {
    margin: 20,
    marginBottom: 20,
  },
  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#EF4444',
    padding: 16,
    borderRadius: 8,
  },
  logoutButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 8,
  },
  footer: {
    alignItems: 'center',
    paddingVertical: 20,
    borderTopWidth: 1,
    borderTopColor: '#F7FAFC',
  },
  footerText: {
    fontSize: 12,
    color: '#A0AEC0',
    marginBottom: 4,
  },
});

export default ProfileScreen;