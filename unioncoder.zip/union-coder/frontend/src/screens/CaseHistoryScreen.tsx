import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Alert,
  RefreshControl,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useChat } from '../contexts/ChatContext';
import { useAuth } from '../contexts/AuthContext';

interface Conversation {
  conversationId: string;
  userId: string;
  personaId: string;
  personaName?: string;
  title: string;
  status: 'active' | 'archived' | 'flagged';
  messages: Array<{
    messageId: string;
    sender: 'user' | 'ai';
    content: string;
    timestamp: Date;
  }>;
  startedAt: Date;
  lastMessageAt: Date;
  isResolved: boolean;
  category?: string;
  tags: string[];
}

const CaseHistoryScreen: React.FC = () => {
  const { 
    conversations, 
    loading, 
    loadConversations, 
    deleteConversation,
    setCurrentConversation 
  } = useChat();
  const { user } = useAuth();
  
  const [refreshing, setRefreshing] = useState(false);
  const [filter, setFilter] = useState<'all' | 'active' | 'resolved'>('all');

  useEffect(() => {
    loadConversations();
  }, []);

  const onRefresh = async () => {
    setRefreshing(true);
    await loadConversations();
    setRefreshing(false);
  };

  const handleDeleteConversation = (conversationId: string) => {
    Alert.alert(
      'Delete Conversation',
      'Are you sure you want to delete this conversation? This action cannot be undone.',
      [
        {
          text: 'Cancel',
          style: 'cancel',
        },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await deleteConversation(conversationId);
              Alert.alert('Success', 'Conversation deleted successfully');
            } catch (error) {
              Alert.alert('Error', 'Failed to delete conversation');
            }
          },
        },
      ]
    );
  };

  const handleOpenConversation = (conversation: Conversation) => {
    setCurrentConversation(conversation);
    // This would typically navigate to the chat tab
    Alert.alert('Navigation', 'Go to Chat tab to view this conversation');
  };

  const formatDate = (date: Date) => {
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

    if (diffDays === 0) {
      return 'Today';
    } else if (diffDays === 1) {
      return 'Yesterday';
    } else if (diffDays < 7) {
      return `${diffDays} days ago`;
    } else {
      return date.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: date.getFullYear() !== now.getFullYear() ? 'numeric' : undefined,
      });
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return '#10B981'; // Green
      case 'resolved':
        return '#3B82F6'; // Blue
      case 'flagged':
        return '#EF4444'; // Red
      default:
        return '#6B7280'; // Gray
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active':
        return 'radio-button-on';
      case 'resolved':
        return 'checkmark-circle';
      case 'flagged':
        return 'flag';
      default:
        return 'help-circle';
    }
  };

  const getFilteredConversations = () => {
    switch (filter) {
      case 'active':
        return conversations.filter(c => c.status === 'active' && !c.isResolved);
      case 'resolved':
        return conversations.filter(c => c.isResolved);
      default:
        return conversations;
    }
  };

  const renderConversationCard = (conversation: Conversation) => {
    const lastMessage = conversation.messages[conversation.messages.length - 1];
    
    return (
      <TouchableOpacity
        key={conversation.conversationId}
        style={styles.conversationCard}
        onPress={() => handleOpenConversation(conversation)}
        activeOpacity={0.7}
      >
        <View style={styles.cardHeader}>
          <View style={styles.personaInfo}>
            <Text style={styles.personaName}>
              {conversation.personaName || 'AI Agent'}
            </Text>
            <View style={styles.statusContainer}>
              <Ionicons 
                name={getStatusIcon(conversation.status) as any}
                size={14} 
                color={getStatusColor(conversation.status)}
              />
              <Text style={[
                styles.statusText,
                { color: getStatusColor(conversation.status) }
              ]}>
                {conversation.status.charAt(0).toUpperCase() + conversation.status.slice(1)}
              </Text>
            </View>
          </View>
          
          <Text style={styles.dateText}>
            {formatDate(conversation.lastMessageAt)}
          </Text>
        </View>

        <Text style={styles.conversationTitle} numberOfLines={2}>
          {conversation.title}
        </Text>

        {lastMessage && (
          <Text style={styles.lastMessage} numberOfLines={2}>
            {lastMessage.sender === 'user' ? 'You: ' : `${conversation.personaName || 'AI'}: `}
            {lastMessage.content}
          </Text>
        )}

        <View style={styles.cardFooter}>
          <View style={styles.tagsContainer}>
            {conversation.category && (
              <View style={styles.categoryTag}>
                <Text style={styles.categoryText}>{conversation.category}</Text>
              </View>
            )}
            {conversation.tags.slice(0, 2).map((tag, index) => (
              <View key={index} style={styles.tag}>
                <Text style={styles.tagText}>{tag}</Text>
              </View>
            ))}
            {conversation.tags.length > 2 && (
              <Text style={styles.moreTagsText}>+{conversation.tags.length - 2}</Text>
            )}
          </View>

          <View style={styles.messageStats}>
            <Ionicons name="chatbubble-outline" size={14} color="#6B7280" />
            <Text style={styles.messageCount}>
              {conversation.messages.length}
            </Text>
          </View>
        </View>

        <TouchableOpacity
          style={styles.deleteButton}
          onPress={() => handleDeleteConversation(conversation.conversationId)}
          activeOpacity={0.7}
        >
          <Ionicons name="trash-outline" size={16} color="#EF4444" />
        </TouchableOpacity>
      </TouchableOpacity>
    );
  };

  const filteredConversations = getFilteredConversations();

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Case History</Text>
        <Text style={styles.headerSubtitle}>
          Your past conversations with AI agents
        </Text>
      </View>

      {/* Filter Tabs */}
      <View style={styles.filterContainer}>
        {(['all', 'active', 'resolved'] as const).map((filterOption) => (
          <TouchableOpacity
            key={filterOption}
            style={[
              styles.filterTab,
              filter === filterOption && styles.activeFilterTab,
            ]}
            onPress={() => setFilter(filterOption)}
          >
            <Text style={[
              styles.filterTabText,
              filter === filterOption && styles.activeFilterTabText,
            ]}>
              {filterOption.charAt(0).toUpperCase() + filterOption.slice(1)}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Conversations List */}
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
        showsVerticalScrollIndicator={false}
      >
        {loading ? (
          <View style={styles.loadingContainer}>
            <Text style={styles.loadingText}>Loading conversations...</Text>
          </View>
        ) : filteredConversations.length > 0 ? (
          filteredConversations.map(renderConversationCard)
        ) : (
          <View style={styles.emptyContainer}>
            <Ionicons name="document-text-outline" size={80} color="#8A2BE2" />
            <Text style={styles.emptyTitle}>
              {filter === 'all' ? 'No conversations yet' : `No ${filter} conversations`}
            </Text>
            <Text style={styles.emptySubtitle}>
              {filter === 'all' 
                ? 'Start a conversation with an AI agent to see it here'
                : `You don't have any ${filter} conversations`
              }
            </Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  header: {
    backgroundColor: '#8A2BE2',
    paddingTop: 60,
    paddingHorizontal: 20,
    paddingBottom: 20,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 8,
  },
  headerSubtitle: {
    fontSize: 16,
    color: '#FFFFFF',
    opacity: 0.9,
  },
  filterContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E2E8F0',
  },
  filterTab: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 12,
    backgroundColor: '#F7FAFC',
  },
  activeFilterTab: {
    backgroundColor: '#8A2BE2',
  },
  filterTabText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#718096',
  },
  activeFilterTabText: {
    color: '#FFFFFF',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    fontSize: 16,
    color: '#4A5568',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 60,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#4A5568',
    marginTop: 20,
    marginBottom: 8,
    textAlign: 'center',
  },
  emptySubtitle: {
    fontSize: 16,
    color: '#718096',
    textAlign: 'center',
    lineHeight: 24,
    paddingHorizontal: 40,
  },
  conversationCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 3.84,
    elevation: 3,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    position: 'relative',
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 8,
  },
  personaInfo: {
    flex: 1,
  },
  personaName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#2D3748',
    marginBottom: 4,
  },
  statusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
    marginLeft: 4,
  },
  dateText: {
    fontSize: 12,
    color: '#718096',
  },
  conversationTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#2D3748',
    marginBottom: 8,
  },
  lastMessage: {
    fontSize: 14,
    color: '#4A5568',
    lineHeight: 20,
    marginBottom: 12,
  },
  cardFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  tagsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    flex: 1,
  },
  categoryTag: {
    backgroundColor: '#FFD700',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    marginRight: 8,
  },
  categoryText: {
    fontSize: 10,
    fontWeight: '600',
    color: '#744210',
  },
  tag: {
    backgroundColor: '#F7FAFC',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    marginRight: 8,
  },
  tagText: {
    fontSize: 10,
    color: '#4A5568',
  },
  moreTagsText: {
    fontSize: 10,
    color: '#718096',
    fontStyle: 'italic',
  },
  messageStats: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  messageCount: {
    fontSize: 12,
    color: '#6B7280',
    marginLeft: 4,
  },
  deleteButton: {
    position: 'absolute',
    top: 16,
    right: 16,
    padding: 8,
    borderRadius: 16,
    backgroundColor: '#FEE2E2',
  },
});

export default CaseHistoryScreen;