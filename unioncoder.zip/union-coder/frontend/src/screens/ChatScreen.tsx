import React, { useEffect, useState, useRef } from 'react';
import {
  View,
  Text,
  ScrollView,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useChat } from '../contexts/ChatContext';
import { useAuth } from '../contexts/AuthContext';

interface Message {
  messageId: string;
  sender: 'user' | 'ai';
  content: string;
  timestamp: Date;
  metadata?: {
    processingTime?: number;
    aiModel?: string;
    tokensUsed?: number;
    confidence?: number;
  };
}

const ChatScreen: React.FC = () => {
  const { 
    currentConversation, 
    conversations, 
    sendMessage, 
    sendingMessage,
    loadConversations 
  } = useChat();
  const { user } = useAuth();
  
  const [message, setMessage] = useState('');
  const scrollViewRef = useRef<ScrollView>(null);

  useEffect(() => {
    loadConversations();
  }, []);

  useEffect(() => {
    // Auto-scroll to bottom when new messages arrive
    if (scrollViewRef.current) {
      setTimeout(() => {
        scrollViewRef.current?.scrollToEnd({ animated: true });
      }, 100);
    }
  }, [currentConversation?.messages]);

  const handleSendMessage = async () => {
    if (!message.trim() || !currentConversation) {
      return;
    }

    const messageToSend = message.trim();
    setMessage('');

    try {
      await sendMessage(currentConversation.conversationId, messageToSend);
    } catch (error) {
      Alert.alert('Error', 'Failed to send message. Please try again.');
      // Restore message if sending failed
      setMessage(messageToSend);
    }
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const renderMessage = (msg: Message, index: number) => {
    const isUser = msg.sender === 'user';
    const showAvatar = index === 0 || conversations[index - 1]?.sender !== msg.sender;

    return (
      <View key={msg.messageId} style={styles.messageContainer}>
        {!isUser && showAvatar && (
          <View style={styles.avatarContainer}>
            <View style={styles.aiAvatar}>
              <Text style={styles.avatarText}>🤖</Text>
            </View>
          </View>
        )}
        
        <View style={[
          styles.messageBubble,
          isUser ? styles.userMessage : styles.aiMessage,
          !showAvatar && isUser && styles.userMessageNoAvatar,
          !showAvatar && !isUser && styles.aiMessageNoAvatar,
        ]}>
          <Text style={[
            styles.messageText,
            isUser ? styles.userMessageText : styles.aiMessageText,
          ]}>
            {msg.content}
          </Text>
          
          <Text style={[
            styles.messageTime,
            isUser ? styles.userMessageTime : styles.aiMessageTime,
          ]}>
            {formatTime(msg.timestamp)}
          </Text>
          
          {msg.metadata && (
            <View style={styles.metadataContainer}>
              {msg.metadata.processingTime && (
                <Text style={styles.metadataText}>
                  ⚡ {msg.metadata.processingTime}ms
                </Text>
              )}
              {msg.metadata.tokensUsed && (
                <Text style={styles.metadataText}>
                  📝 {msg.metadata.tokensUsed} tokens
                </Text>
              )}
            </View>
          )}
        </View>
        
        {isUser && showAvatar && (
          <View style={styles.avatarContainer}>
            <View style={styles.userAvatar}>
              <Text style={styles.avatarText}>
                {user?.displayName?.charAt(0).toUpperCase() || 'U'}
              </Text>
            </View>
          </View>
        )}
      </View>
    );
  };

  if (!currentConversation) {
    return (
      <View style={styles.emptyContainer}>
        <View style={styles.emptyContent}>
          <Ionicons name="chatbubble-outline" size={80} color="#8A2BE2" />
          <Text style={styles.emptyTitle}>No Active Conversation</Text>
          <Text style={styles.emptySubtitle}>
            Select an AI agent from the Personas tab to start a conversation
          </Text>
          <TouchableOpacity style={styles.startButton}>
            <Text style={styles.startButtonText}>Choose AI Agent</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView 
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      {/* Chat Header */}
      <View style={styles.header}>
        <View style={styles.headerInfo}>
          <Text style={styles.headerTitle}>
            {currentConversation.personaName || 'AI Agent'}
          </Text>
          <Text style={styles.headerStatus}>
            {currentConversation.status === 'active' ? '🟢 Online' : '🟡 Away'}
          </Text>
        </View>
        
        <TouchableOpacity style={styles.headerButton}>
          <Ionicons name="ellipsis-vertical" size={20} color="#FFFFFF" />
        </TouchableOpacity>
      </View>

      {/* Messages */}
      <ScrollView
        ref={scrollViewRef}
        style={styles.messagesContainer}
        contentContainerStyle={styles.messagesContent}
        showsVerticalScrollIndicator={false}
      >
        {currentConversation.messages.map((msg, index) => renderMessage(msg, index))}
        
        {sendingMessage && (
          <View style={styles.typingIndicator}>
            <View style={styles.typingDot} />
            <View style={[styles.typingDot, { marginLeft: 8 }]} />
            <View style={[styles.typingDot, { marginLeft: 8 }]} />
          </View>
        )}
      </ScrollView>

      {/* Message Input */}
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.textInput}
          placeholder="Type your message..."
          placeholderTextColor="#A0AEC0"
          value={message}
          onChangeText={setMessage}
          multiline
          maxLength={1000}
          editable={!sendingMessage}
        />
        
        <TouchableOpacity
          style={[
            styles.sendButton,
            (!message.trim() || sendingMessage) && styles.disabledSendButton,
          ]}
          onPress={handleSendMessage}
          disabled={!message.trim() || sendingMessage}
        >
          <Ionicons 
            name="send" 
            size={20} 
            color={message.trim() && !sendingMessage ? '#FFFFFF' : '#A0AEC0'} 
          />
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  emptyContainer: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 40,
  },
  emptyContent: {
    alignItems: 'center',
  },
  emptyTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#2D3748',
    marginTop: 20,
    marginBottom: 12,
  },
  emptySubtitle: {
    fontSize: 16,
    color: '#718096',
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: 32,
  },
  startButton: {
    backgroundColor: '#8A2BE2',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
  },
  startButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  header: {
    backgroundColor: '#8A2BE2',
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  headerInfo: {
    flex: 1,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  headerStatus: {
    fontSize: 14,
    color: '#FFFFFF',
    opacity: 0.9,
  },
  headerButton: {
    padding: 8,
  },
  messagesContainer: {
    flex: 1,
  },
  messagesContent: {
    padding: 16,
  },
  messageContainer: {
    flexDirection: 'row',
    marginBottom: 16,
    alignItems: 'flex-end',
  },
  avatarContainer: {
    width: 32,
    alignItems: 'center',
  },
  aiAvatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#E2E8F0',
    justifyContent: 'center',
    alignItems: 'center',
  },
  userAvatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#8A2BE2',
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  messageBubble: {
    maxWidth: '70%',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 16,
  },
  userMessage: {
    backgroundColor: '#8A2BE2',
    marginLeft: 'auto',
    borderBottomRightRadius: 4,
  },
  userMessageNoAvatar: {
    marginLeft: 48,
  },
  aiMessage: {
    backgroundColor: '#F7FAFC',
    borderWidth: 1,
    borderColor: '#E2E8F0',
    marginRight: 'auto',
    borderBottomLeftRadius: 4,
  },
  aiMessageNoAvatar: {
    marginRight: 48,
  },
  messageText: {
    fontSize: 16,
    lineHeight: 22,
    marginBottom: 4,
  },
  userMessageText: {
    color: '#FFFFFF',
  },
  aiMessageText: {
    color: '#2D3748',
  },
  messageTime: {
    fontSize: 12,
    marginTop: 4,
  },
  userMessageTime: {
    color: 'rgba(255, 255, 255, 0.8)',
    textAlign: 'right',
  },
  aiMessageTime: {
    color: '#718096',
  },
  metadataContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: 4,
    gap: 8,
  },
  metadataText: {
    fontSize: 10,
    color: '#A0AEC0',
  },
  typingIndicator: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
    padding: 16,
    marginLeft: 48,
  },
  typingDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#CBD5E0',
    animation: 'typing 1.4s infinite ease-in-out',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#FFFFFF',
    borderTopWidth: 1,
    borderTopColor: '#E2E8F0',
  },
  textInput: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 16,
    color: '#2D3748',
    maxHeight: 100,
    marginRight: 12,
    backgroundColor: '#F7FAFC',
  },
  sendButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#FF8C00',
    justifyContent: 'center',
    alignItems: 'center',
  },
  disabledSendButton: {
    backgroundColor: '#CBD5E0',
  },
});

export default ChatScreen;