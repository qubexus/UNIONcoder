import React, { createContext, useContext, useState, ReactNode } from 'react';

interface Message {
  messageId: string;
  sender: 'user' | 'ai';
  content: string;
  timestamp: Date;
  metadata?: {
    processingTime?: number;
    aiModel?: string;
    tokensUsed?: number;
    confidence?: number;
  };
}

interface Conversation {
  conversationId: string;
  userId: string;
  personaId: string;
  personaName?: string;
  title: string;
  status: 'active' | 'archived' | 'flagged';
  messages: Message[];
  startedAt: Date;
  lastMessageAt: Date;
  isResolved: boolean;
  category?: string;
  tags: string[];
}

interface AIPersona {
  personaId: string;
  name: string;
  title: string;
  specialization: string;
  description: string;
  avatar: string;
  isActive: boolean;
  sortOrder: number;
}

interface ChatContextType {
  conversations: Conversation[];
  currentConversation: Conversation | null;
  personas: AIPersona[];
  loading: boolean;
  creatingConversation: boolean;
  sendingMessage: boolean;
  
  // Actions
  loadPersonas: () => Promise<void>;
  loadConversations: () => Promise<void>;
  createConversation: (personaId: string, initialMessage: string) => Promise<Conversation>;
  sendMessage: (conversationId: string, content: string) => Promise<void>;
  setCurrentConversation: (conversation: Conversation | null) => void;
  deleteConversation: (conversationId: string) => Promise<void>;
}

const ChatContext = createContext<ChatContextType | undefined>(undefined);

interface ChatProviderProps {
  children: ReactNode;
}

export const ChatProvider: React.FC<ChatProviderProps> = ({ children }) => {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [currentConversation, setCurrentConversation] = useState<Conversation | null>(null);
  const [personas, setPersonas] = useState<AIPersona[]>([]);
  const [loading, setLoading] = useState(false);
  const [creatingConversation, setCreatingConversation] = useState(false);
  const [sendingMessage, setSendingMessage] = useState(false);

  // API base URL - in production, this should come from environment variables
  const API_BASE_URL = 'http://localhost:3000/api';

  const loadPersonas = async () => {
    try {
      setLoading(true);
      const response = await fetch(`${API_BASE_URL}/personas/active`);
      const data = await response.json();

      if (data.success) {
        setPersonas(data.data);
      }
    } catch (error) {
      console.error('Error loading personas:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadConversations = async () => {
    try {
      setLoading(true);
      const response = await fetch(`${API_BASE_URL}/chat/conversations`);
      const data = await response.json();

      if (data.success) {
        setConversations(data.data.map((conv: any) => ({
          ...conv,
          startedAt: new Date(conv.startedAt),
          lastMessageAt: new Date(conv.lastMessageAt),
          messages: conv.messages.map((msg: any) => ({
            ...msg,
            timestamp: new Date(msg.timestamp),
          })),
        })));
      }
    } catch (error) {
      console.error('Error loading conversations:', error);
    } finally {
      setLoading(false);
    }
  };

  const createConversation = async (personaId: string, initialMessage: string): Promise<Conversation> => {
    try {
      setCreatingConversation(true);
      
      const response = await fetch(`${API_BASE_URL}/chat/conversations`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          personaId,
          initialMessage,
        }),
      });

      const data = await response.json();

      if (data.success) {
        const newConversation = {
          ...data.data,
          startedAt: new Date(data.data.startedAt),
          lastMessageAt: new Date(data.data.lastMessageAt),
          messages: data.data.messages.map((msg: any) => ({
            ...msg,
            timestamp: new Date(msg.timestamp),
          })),
        };

        setConversations(prev => [newConversation, ...prev]);
        setCurrentConversation(newConversation);
        
        return newConversation;
      } else {
        throw new Error(data.message || 'Failed to create conversation');
      }
    } catch (error) {
      console.error('Error creating conversation:', error);
      throw error;
    } finally {
      setCreatingConversation(false);
    }
  };

  const sendMessage = async (conversationId: string, content: string) => {
    try {
      setSendingMessage(true);

      const response = await fetch(`${API_BASE_URL}/chat/messages`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          conversationId,
          content,
        }),
      });

      const data = await response.json();

      if (data.success) {
        const aiMessage = {
          ...data.data.message,
          timestamp: new Date(data.data.message.timestamp),
        };

        // Update conversation in state
        setConversations(prev => prev.map(conv => {
          if (conv.conversationId === conversationId) {
            const updatedConversation = {
              ...conv,
              messages: [...conv.messages, {
                messageId: `msg_${Date.now()}`,
                sender: 'user' as const,
                content,
                timestamp: new Date(),
              }, aiMessage],
              lastMessageAt: new Date(),
            };

            if (currentConversation?.conversationId === conversationId) {
              setCurrentConversation(updatedConversation);
            }

            return updatedConversation;
          }
          return conv;
        }));
      } else {
        throw new Error(data.message || 'Failed to send message');
      }
    } catch (error) {
      console.error('Error sending message:', error);
      throw error;
    } finally {
      setSendingMessage(false);
    }
  };

  const deleteConversation = async (conversationId: string) => {
    try {
      const response = await fetch(`${API_BASE_URL}/chat/conversations/${conversationId}`, {
        method: 'DELETE',
      });

      const data = await response.json();

      if (data.success) {
        setConversations(prev => prev.filter(conv => conv.conversationId !== conversationId));
        
        if (currentConversation?.conversationId === conversationId) {
          setCurrentConversation(null);
        }
      } else {
        throw new Error(data.message || 'Failed to delete conversation');
      }
    } catch (error) {
      console.error('Error deleting conversation:', error);
      throw error;
    }
  };

  const value: ChatContextType = {
    conversations,
    currentConversation,
    personas,
    loading,
    creatingConversation,
    sendingMessage,
    loadPersonas,
    loadConversations,
    createConversation,
    sendMessage,
    setCurrentConversation,
    deleteConversation,
  };

  return (
    <ChatContext.Provider value={value}>
      {children}
    </ChatContext.Provider>
  );
};

export const useChat = (): ChatContextType => {
  const context = useContext(ChatContext);
  if (context === undefined) {
    throw new Error('useChat must be used within a ChatProvider');
  }
  return context;
};