import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import auth from '@react-native-firebase/auth';
import firestore from '@react-native-firebase/firestore';
import AsyncStorage from '@react-native-async-storage/async-storage';

interface User {
  uid: string;
  email: string;
  displayName?: string;
  currentEmployer?: string;
  department?: string;
  jobTitle?: string;
  isActive: boolean;
  createdAt: Date;
  lastLoginAt: Date;
}

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (email: string, password: string, displayName: string) => Promise<void>;
  logout: () => Promise<void>;
  updateProfile: (data: Partial<User>) => Promise<void>;
  createProfile: (data: Partial<User>) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const subscriber = auth().onAuthStateChanged(handleAuthStateChanged);
    return subscriber;
  }, []);

  const handleAuthStateChanged = async (firebaseUser: any) => {
    setLoading(true);
    
    if (firebaseUser) {
      try {
        // Get user profile from Firestore
        const userDoc = await firestore()
          .collection('users')
          .where('userId', '==', firebaseUser.uid)
          .limit(1)
          .get();

        if (userDoc.docs.length > 0) {
          const userData = userDoc.docs[0].data() as User;
          setUser({
            ...userData,
            uid: firebaseUser.uid,
          });

          // Update last login
          await firestore()
            .collection('users')
            .doc(userDoc.docs[0].id)
            .update({
              lastLoginAt: firestore.FieldValue.serverTimestamp(),
            });

          // Track login in backend
          await trackLogin(firebaseUser);
        } else {
          // User exists in Firebase Auth but not in Firestore
          setUser({
            uid: firebaseUser.uid,
            email: firebaseUser.email || '',
            displayName: firebaseUser.displayName || '',
            isActive: true,
            createdAt: new Date(),
            lastLoginAt: new Date(),
          });
        }
      } catch (error) {
        console.error('Error fetching user profile:', error);
      }
    } else {
      setUser(null);
    }
    
    setLoading(false);
  };

  const trackLogin = async (firebaseUser: any) => {
    try {
      // Here you would make an API call to your backend
      // For now, we'll just store in AsyncStorage
      await AsyncStorage.setItem('lastLogin', new Date().toISOString());
    } catch (error) {
      console.error('Error tracking login:', error);
    }
  };

  const login = async (email: string, password: string) => {
    try {
      await auth().signInWithEmailAndPassword(email, password);
    } catch (error: any) {
      let message = 'Login failed';
      
      if (error.code === 'auth/user-not-found') {
        message = 'User not found. Please check your email.';
      } else if (error.code === 'auth/wrong-password') {
        message = 'Incorrect password. Please try again.';
      } else if (error.code === 'auth/invalid-email') {
        message = 'Invalid email address.';
      } else if (error.code === 'auth/user-disabled') {
        message = 'This account has been disabled.';
      } else if (error.code === 'auth/too-many-requests') {
        message = 'Too many failed attempts. Please try again later.';
      }
      
      throw new Error(message);
    }
  };

  const register = async (email: string, password: string, displayName: string) => {
    try {
      const result = await auth().createUserWithEmailAndPassword(email, password);
      
      if (result.user) {
        await result.user.updateProfile({ displayName });
      }
    } catch (error: any) {
      let message = 'Registration failed';
      
      if (error.code === 'auth/email-already-in-use') {
        message = 'This email is already registered.';
      } else if (error.code === 'auth/weak-password') {
        message = 'Password is too weak. Please choose a stronger password.';
      } else if (error.code === 'auth/invalid-email') {
        message = 'Invalid email address.';
      }
      
      throw new Error(message);
    }
  };

  const logout = async () => {
    try {
      await auth().signOut();
      await AsyncStorage.removeItem('lastLogin');
    } catch (error) {
      console.error('Error during logout:', error);
      throw new Error('Logout failed');
    }
  };

  const createProfile = async (data: Partial<User>) => {
    if (!user) {
      throw new Error('User not authenticated');
    }

    try {
      const profileData = {
        userId: user.uid,
        email: user.email,
        displayName: data.displayName || user.displayName,
        currentEmployer: data.currentEmployer || '',
        department: data.department || '',
        jobTitle: data.jobTitle || '',
        isActive: true,
        createdAt: firestore.FieldValue.serverTimestamp(),
        lastLoginAt: firestore.FieldValue.serverTimestamp(),
        updatedAt: firestore.FieldValue.serverTimestamp(),
      };

      await firestore().collection('users').add(profileData);
      
      setUser(prev => prev ? { ...prev, ...data } : null);
    } catch (error) {
      console.error('Error creating profile:', error);
      throw new Error('Failed to create profile');
    }
  };

  const updateProfile = async (data: Partial<User>) => {
    if (!user) {
      throw new Error('User not authenticated');
    }

    try {
      const userDoc = await firestore()
        .collection('users')
        .where('userId', '==', user.uid)
        .limit(1)
        .get();

      if (userDoc.docs.length > 0) {
        const docId = userDoc.docs[0].id;
        await firestore()
          .collection('users')
          .doc(docId)
          .update({
            ...data,
            updatedAt: firestore.FieldValue.serverTimestamp(),
          });
        
        setUser(prev => prev ? { ...prev, ...data } : null);
      } else {
        throw new Error('User profile not found');
      }
    } catch (error) {
      console.error('Error updating profile:', error);
      throw new Error('Failed to update profile');
    }
  };

  const value: AuthContextType = {
    user,
    loading,
    login,
    register,
    logout,
    updateProfile,
    createProfile,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};