import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import { StatusBar } from 'expo-status-bar';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

// Import screens
import PersonaSelectionScreen from './src/screens/PersonaSelectionScreen';
import ChatScreen from './src/screens/ChatScreen';
import CaseHistoryScreen from './src/screens/CaseHistoryScreen';
import ProfileScreen from './src/screens/ProfileScreen';
import LoginScreen from './src/screens/LoginScreen';

// Import providers
import { AuthProvider } from './src/contexts/AuthContext';
import { ChatProvider } from './src/contexts/ChatContext';

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

// Main tab navigator for authenticated users
function MainTabNavigator() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          let iconName: keyof typeof Ionicons.glyphMap;

          if (route.name === 'Personas') {
            iconName = focused ? 'people' : 'people-outline';
          } else if (route.name === 'Chat') {
            iconName = focused ? 'chatbubble' : 'chatbubble-outline';
          } else if (route.name === 'History') {
            iconName = focused ? 'time' : 'time-outline';
          } else if (route.name === 'Profile') {
            iconName = focused ? 'person' : 'person-outline';
          } else {
            iconName = 'help-outline';
          }

          return <Ionicons name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: '#8A2BE2', // Brand purple
        tabBarInactiveTintColor: '#4A5568', // Neutral gray
        tabBarStyle: {
          backgroundColor: '#FFFFFF', // Primary white
          borderTopColor: '#E2E8F0',
        },
        headerStyle: {
          backgroundColor: '#8A2BE2', // Brand purple
        },
        headerTintColor: '#FFFFFF', // White text
        headerTitleStyle: {
          fontWeight: 'bold',
        },
      })}
    >
      <Tab.Screen 
        name="Personas" 
        component={PersonaSelectionScreen} 
        options={{ title: 'AI Agents' }}
      />
      <Tab.Screen 
        name="Chat" 
        component={ChatScreen} 
        options={{ title: 'Chat' }}
      />
      <Tab.Screen 
        name="History" 
        component={CaseHistoryScreen} 
        options={{ title: 'Case History' }}
      />
      <Tab.Screen 
        name="Profile" 
        component={ProfileScreen} 
        options={{ title: 'My Profile' }}
      />
    </Tab.Navigator>
  );
}

// Authentication stack
function AuthStack() {
  return (
    <Stack.Navigator 
      screenOptions={{
        headerStyle: {
          backgroundColor: '#8A2BE2', // Brand purple
        },
        headerTintColor: '#FFFFFF', // White text
        headerTitleStyle: {
          fontWeight: 'bold',
        },
      }}
    >
      <Stack.Screen 
        name="Login" 
        component={LoginScreen} 
        options={{ title: 'UNIONcoder Login' }}
      />
      <Stack.Screen 
        name="Main" 
        component={MainTabNavigator} 
        options={{ headerShown: false }}
      />
    </Stack.Navigator>
  );
}

// Main app component
export default function App() {
  return (
    <AuthProvider>
      <ChatProvider>
        <NavigationContainer>
          <View style={styles.container}>
            <StatusBar style="light" backgroundColor="#8A2BE2" />
            <AuthStack />
          </View>
        </NavigationContainer>
      </ChatProvider>
    </AuthProvider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF', // Primary white background
  },
});