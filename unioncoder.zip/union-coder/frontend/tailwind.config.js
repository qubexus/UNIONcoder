/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./App.{js,jsx,ts,tsx}", "./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        // UNIONcoder Brand Colors
        primary: "#FFFFFF",      // White background
        neutral: "#4A5568",      // Gray text/borders
        accent: "#FF8C00",       // Orange CTA buttons
        warning: "#FFD700",      // Yellow status indicators
        brand: "#8A2BE2",        // Purple header/navigation
      },
      fontFamily: {
        sans: ["System", "sans-serif"],
      },
      spacing: {
        '18': '4.5rem',
        '88': '22rem',
      },
    },
  },
  plugins: [],
}